package hoge.bohe.foo;

public class ConstTest
{
	public static final String const1 = "const1-1";
	public static final int const2 = 123;
	public static final String getConst3() { return "const3-1"; }
	public final String getConst4() { return "const4-1"; }
	public String getConst5() { return "const5-1"; }
	public static String const6 = "const6-1";
	public final String const7 = "const7-1";
}
