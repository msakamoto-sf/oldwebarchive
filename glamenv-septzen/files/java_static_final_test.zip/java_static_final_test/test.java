import hoge.bohe.foo.ConstTest;
public class test 
{
public static void main(String[] args)
{
System.out.println(ConstTest.const1);
System.out.println(ConstTest.const2);
System.out.println(ConstTest.getConst3());
ConstTest ct = new ConstTest();

System.out.println(ct.getConst4());
System.out.println(ct.getConst5());
System.out.println(ConstTest.const6);
System.out.println(ct.const7);
}
}
