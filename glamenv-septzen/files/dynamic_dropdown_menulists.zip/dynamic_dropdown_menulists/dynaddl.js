var dynaddl = {
    _base : null, // 'show'/'hide' display changing HTML DOM Node
    _current_id : 0,
    _items : {
        'ID001' : 'Item_001',
        'ID002' : 'Item_002',
        'ID003' : 'Item_003'
    },

    set_current : function(new_id) {
        this._current_id  = new_id;
    },

    onselect : function(item_id) {
        if (item_id == this._current_id) {
            alert('same, do nothing.');
            this.hide_ddl(this._base);
        } else {
            alert('different, selected id is ' + item_id);
        }
        return false;
    },

    hide_ddl : function(base) {
        var ddl = $('ddlist');
        ddl.setStyle({display: 'none'});
        base.value = 'show';
    },

    toggle_ddl : function(base) {
        this._base = base;
        var ddl = $('ddlist');
        var curr_display = ddl.getStyle('display');
        if ('none' == curr_display) {
            this.update_ddl_items();
            var offset = Position.cumulativeOffset(base);
            ddl.setStyle({
                display: 'block',
                left: offset[0] + "px",
                top: offset[1] + 20 + "px"
            });
            base.value = 'hide';
        } else {
            this.hide_ddl(base);
        }
    },

    update_ddl_items : function() {
        var ddl = $('ddlist');

        // ... in REAL code, call ajax and {parse xml | eval json}, 
        // update "this._items" hash object...

        // remove old items
        while (ddl.hasChildNodes()) {
            ddl.removeChild(ddl.firstChild);
        }

        for (var key in this._items) {

            var caption = this._items[key];

            (function(){
            // split scope using anonymouse function call

            var id = key; // copy
            var label = document.createTextNode(caption);
            var aElement = document.createElement('a');
            Event.observe(
                    aElement, 
                    'click', 
                    function() { dynaddl.onselect(id); }
                    );
            aElement.setAttribute('href', '#');
            aElement.appendChild(label);
            var liElement = document.createElement('li');
            liElement.appendChild(aElement);

            ddl.appendChild(liElement);

            })();
        }
    }
};
