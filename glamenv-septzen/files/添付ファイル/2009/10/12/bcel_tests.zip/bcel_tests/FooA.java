public abstract class FooA {
    public abstract String fooA(int i);
}
