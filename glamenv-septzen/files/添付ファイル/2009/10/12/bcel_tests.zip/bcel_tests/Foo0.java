public class Foo0 {
    static String name = "Foo0";
}
