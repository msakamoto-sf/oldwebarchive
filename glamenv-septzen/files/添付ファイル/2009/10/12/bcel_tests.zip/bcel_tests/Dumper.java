
import org.apache.bcel.Repository;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;
import org.apache.bcel.classfile.Field;


public class Dumper {
    public static void dump(Class clazz) throws Exception {
        JavaClass jc = Repository.lookupClass(clazz);
        Dumper.dump(jc);
    }
    public static void dump(String clazz) throws Exception {
        JavaClass jc = Repository.lookupClass(clazz);
        Dumper.dump(jc);
    }
    public static void dump(JavaClass jc) throws Exception {
        String s = jc.getClassName();
        System.out.println("==============================================");
        System.out.println("classname = " + s);
        s = jc.getSuperclassName();
        System.out.println("superclassname = " + s);
        System.out.println("----------------------------------------------");
        String[] interfaces = jc.getInterfaceNames();
        for (int i = 0; i < interfaces.length; i++) {
            System.out.println("interface[" + i + "] = " + interfaces[i].toString());
        }
        System.out.println("----------------------------------------------");
        Field[] fields = jc.getFields();
        for (int i = 0; i < fields.length; i++) {
            System.out.println("fields[" + i + "] = " + fields[i].toString());
            System.out.println("  name = " + fields[i].getName());
            System.out.println("  sign = " + fields[i].getSignature());
            System.out.println("  synthetic = " + fields[i].isSynthetic());
        }
        System.out.println("----------------------------------------------");
        Method[] methods = jc.getMethods();
        for (int i = 0; i < methods.length; i++) {
            System.out.println("methods[" + i + "] = " + methods[i].toString());
            System.out.println("  name = " + methods[i].getName());
            System.out.println("  sign = " + methods[i].getSignature());
            System.out.println("  synthetic = " + methods[i].isSynthetic());
            System.out.println("  ret = " + methods[i].getReturnType());
            System.out.println("  code = " + methods[i].getCode());
        }
        System.out.println("==============================================");
    }
    public static void main(String[] args) throws Exception {
        Dumper.dump(args[0]);
    }
}
