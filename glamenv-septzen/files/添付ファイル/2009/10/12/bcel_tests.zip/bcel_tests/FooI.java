public interface FooI {
    public String fooI(int j);
}
