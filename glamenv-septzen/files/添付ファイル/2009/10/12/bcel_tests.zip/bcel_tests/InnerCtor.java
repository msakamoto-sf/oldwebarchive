public class InnerCtor {
    public static void main(String[] args) throws Exception {
        FooA fa = new FooA() {
            public String fooA(int i) { return "FooA" + i; }
        };
        FooI fi = new FooI() {
            public String fooI(int j) { return "FooI" + j; }
        };
        System.out.println("Dump innerclass(abstract) in static:");
        Dumper.dump(fa.getClass());
        System.out.println("Dump innerclass(interface) in static:");
        Dumper.dump(fi.getClass());
        
        System.out.println("----------------------------------");
        new InnerCtor().instanceMethod();
    }
    
    public void instanceMethod() throws Exception {
        FooA fa = new FooA() {
            public String fooA(int i) { return "FooA" + i; }
        };
        FooI fi = new FooI() {
            public String fooI(int j) { return "FooI" + j; }
        };
        System.out.println("Dump innerclass(abstract) in instance:");
        Dumper.dump(fa.getClass());
        System.out.println("Dump innerclass(interface) in instance:");
        Dumper.dump(fi.getClass());
    }
}
