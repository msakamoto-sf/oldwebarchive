public class Foo1 extends Foo0 {
    public Foo1() {}
    static String name = "Foo1";
}
