drop table tblob1;
create table tblob1 (
	id integer auto_increment not null,
	name varchar(255) not null,
	original_file_name varchar(255) not null,
	data mediumblob,
	data_size integer,
	primary key(id, original_file_name)
);
