<?php
require_once("../adodb/adodb.inc.php");

if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
	die("id parameter is not valid id");
}

$conn =& NewADOConnection("mysql://msakamoto:msakamoto@localhost/msakamoto");
if(!$conn) {
	die("Connection Failure");
}

$sql = "select original_file_name, data, data_size from tblob1 where id = ?";
$stmt = $conn->Prepare($sql);
$rs =& $conn->Execute($stmt, array($_GET['id']));
$record = array();
if(!$rs) {
	$smarty->assign('select_errormsg',
		$conn->ErrorNo().":".$conn->ErrorMsg());
} else {
	$record = $rs->FetchRow();
}
$rs->close();
$fn = $record['original_file_name'];
$data = $record['data'];
$size = $record['data_size'];

header("Content-Length: ".$size);
if(preg_match("/\.gif/i", $fn)) {
	header("Content-Type: image/gif");
} else if(preg_match("/\.jpeg|\.jpg/i", $fn)) {
	header("Content-Type: image/jpeg");
} else {
	exit(1);
}

echo $data;
?>
