<?php


ob_start();
print "<pre>\n";
print_r($_COOKIE);
print "</pre>\n";

setcookie("a", 1);
setcookie("b", 2);

$_COOKIE["a"]++;
$_COOKIE["b"]++;

ob_end_flush();
?>
