<?php

session_set_cookie_params(60, "/", null, null);
session_start();
if(!isset($_SESSION["hoge"])) {
	$_SESSION["hoge"] = array(0, 1, 2, 3);
}

$arr =& $_SESSION["hoge"];
$arr[0] = $arr[0] + 1;

if($arr[0] > 5) {
	$arr['hoge'] = "hogehoge";
}

if(isset($_COOKIE["val1"])) {
	$_COOKIE["val1"] += 2;
	setcookie("val1", $_COOKIE["val1"]);
} else {
	setcookie("val1", 0);
}

if(isset($_COOKIE["val2"])) {
	$_COOKIE["val2"] += 3;
	setcookie("val2", $_COOKIE["val2"]);
} else {
	setcookie("val2", 1);
}

print_r($arr);

var_dump($_SESSION);
var_dump($_COOKIE);
/*
$arr = array(
	"hoge" => "bohe",
	"mugyo" => "mogyaa",
	"mohu" => "hogya",
	);

print $arr."\n";
print_r($arr);
var_dump($arr);
print isset($arr);


$arr = array();
print $arr."\n";
print_r($arr);
var_dump($arr);

*/



?>
