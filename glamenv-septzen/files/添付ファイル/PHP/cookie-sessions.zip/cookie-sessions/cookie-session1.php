<?php

session_set_cookie_params(60, "/", null, null);

session_start();

if(!isset($_SESSION["hoge"])) {
	$_SESSION["hoge"] = array(0, 1, 2, 3);
}

$arr =& $_SESSION["hoge"];
$arr[0] = $arr[0] + 1;

if($arr[0] > 5) {
	$arr['hoge'] = "hogehoge";
}

print_r($arr);

var_dump($_SESSION);

/*
$arr = array(
	"hoge" => "bohe",
	"mugyo" => "mogyaa",
	"mohu" => "hogya",
	);

print $arr."\n";
print_r($arr);
var_dump($arr);
print isset($arr);


$arr = array();
print $arr."\n";
print_r($arr);
var_dump($arr);

*/



?>
