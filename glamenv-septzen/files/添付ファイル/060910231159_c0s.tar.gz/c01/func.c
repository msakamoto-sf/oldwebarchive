int count = 0;

void func01(char *msg)
{
	count++;
	printf("msg = [%s]\n", msg);
	printf("[%d] times called.\n", count);
}

