<?php
setcookie('cookie2', '123456', 0, '/iecookie2');
?>
<html>
<body>
<h3>application 2</h3>
<?php var_dump($_COOKIE); ?>
<hr />
<a href="./test3.php" target="_blank">blank link</a><br />
<a href="javascript:func1()" >popup</a>
<script language="JavaScript">
<!--
function func1()
{
    var args = new Object;
    args.window = window;
    window.showModalDialog(
        "./popup.php",
        args,
        "dialogWidth:320px;dialogHeight:240px"
        );
}
-->
</script>
</body>
</html>
