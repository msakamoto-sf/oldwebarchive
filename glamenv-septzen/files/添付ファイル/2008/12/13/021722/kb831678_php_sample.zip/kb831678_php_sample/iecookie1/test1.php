<?php
setcookie('cookie1', 'ABCDEFG', 0, '/iecookie1');
?>
<html>
<body>
<h3>application 1</h3>
<?php var_dump($_COOKIE); ?>
</body>
</html>
