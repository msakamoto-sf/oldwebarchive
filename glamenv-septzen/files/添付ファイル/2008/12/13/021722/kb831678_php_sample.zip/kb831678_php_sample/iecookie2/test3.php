<html>
<body>
<h3>application 3</h3>
<?php var_dump($_COOKIE); ?>
</body>
</html>
