<html>
<body>
<h3>popup bridge pgae</h3>
<?php var_dump($_COOKIE); ?>
<hr />
<a href="./test3.php" target="_blank">blank link</a><br /><br />
<a href="javascript:func2()">popup more!</a>
<script language="JavaScript">
<!--
function func2()
{
    dialogArguments.window.open("./test3.php", null);
}
-->
</script>
</body>
</html>
