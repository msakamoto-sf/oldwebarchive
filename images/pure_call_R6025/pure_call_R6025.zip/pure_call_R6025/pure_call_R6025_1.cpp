#include <stdio.h>

class B {
public:
    B() { bar(); };
    void bar() { this->foo(); };
    virtual void foo() = 0;
};
void B::foo() { printf("B::foo()\n"); }
class D : public B {
public:
    void foo() { printf("D::foo()\n"); };
};
int main() {
    D d;
    return 0;
}
