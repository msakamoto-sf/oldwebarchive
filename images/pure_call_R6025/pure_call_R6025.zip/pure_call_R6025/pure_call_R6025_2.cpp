class B {
public:
    int a;
    int b;
    B();
    int f0();
    virtual int f1() = 0;
    virtual int f2();
    virtual int f3();
};
B::B() { a = f0(); }
int B::f0() { return f1(); }
int B::f2() { return a + b; }
int B::f3() { return a * b; }

class D : public B {
public:
    int c;
    int d;
    int e;
    int f1();
    int f4();
    int f5();
};
int D::f1() { return c + d; }
int D::f4() { return d + e; }
int D::f5() { return e + c; }


int main() {
    D d;
    return 0;
}
