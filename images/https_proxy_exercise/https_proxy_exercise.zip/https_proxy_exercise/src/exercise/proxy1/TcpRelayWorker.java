package exercise.proxy1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.net.Socket;

public class TcpRelayWorker extends Thread {
    protected Socket readFrom;
    protected Socket writeTo;

    public TcpRelayWorker(String _name, Socket _readFrom, Socket _writeTo) {
        super(_name);
        this.readFrom = _readFrom;
        this.writeTo = _writeTo;
    }

    public void run() {
        int len_r = 0;
        byte[] data = new byte[1024];
        String name_from = this.readFrom.getInetAddress().toString() + ":"
                + this.readFrom.getPort();
        String name_to = this.writeTo.getInetAddress().toString() + ":"
                + this.writeTo.getPort();
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            bis = new BufferedInputStream(this.readFrom.getInputStream());
            bos = new BufferedOutputStream(this.writeTo.getOutputStream());
            while (
                    !this.readFrom.isClosed() 
                    && !this.writeTo.isClosed() 
                    && (-1 != (len_r = bis.read(data)))
                    ) {
                System.out.println("read(" + name_from + "):" + len_r);
                bos.write(data, 0, len_r);
                bos.flush();
                System.out.println("write(" + name_to + "):" + len_r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { bis.close(); } catch (Exception ignore) {}
            try { bos.close(); } catch (Exception ignore) {}
        }
    }
}
