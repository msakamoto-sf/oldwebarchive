package exercise.proxy1;

import java.io.IOException;
import java.net.Socket;

import org.apache.http.HttpServerConnection;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.protocol.HttpService;

public class ProxyWorker extends Thread {
    private final HttpService httpservice;
    private final HttpServerConnection inconn;
    private final Socket insocket;
    
    public ProxyWorker(
            final HttpService httpservice, 
            final HttpServerConnection inconn, 
            final Socket insocket) {
        super();
        this.httpservice = httpservice;
        this.inconn = inconn;
        this.insocket = insocket;
    }
    
    public void run() {
        System.out.println("New connection thread");
        HttpContext context = new BasicHttpContext(null);
        boolean switchToHttps = false;
        context.setAttribute("switch_to_https", switchToHttps);
        context.setAttribute("https.host", "");
        context.setAttribute("https.port", -1);
        try {
            while (!Thread.interrupted() && inconn.isOpen()) {
                switchToHttps = (Boolean)context.getAttribute("switch_to_https");
                if (switchToHttps) {
                    System.out.println("Switching HTTPS Tunneling mode...");
                    break;
                } else {
                    System.out.println("handleRequest start");
                    this.httpservice.handleRequest(this.inconn, context);
                    switchToHttps = (Boolean)context.getAttribute("switch_to_https");
                    if (!switchToHttps) {
                        this.inconn.close();
                    }
                    System.out.println("handleRequest end");
                }
            }
            if (switchToHttps) {
                String targetHost = (String)context.getAttribute("https.host");
                int targetPort = (Integer)context.getAttribute("https.port");
                System.out.println("HTTPS : host=[" + targetHost + "], port=[" + targetPort + "]");
                Socket targetSocket = null;
                if ("localhost".equals(targetHost) && 8081 == targetPort) {
                    // redirect to TLS relay server
                    targetSocket = new Socket("localhost", 8889);
                } else {
                    targetSocket = new Socket(targetHost, targetPort);
                }
                Thread in2target = new TcpRelayWorker("in2target", insocket, targetSocket);
                in2target.setDaemon(true);
                in2target.start();
                Thread target2in = new TcpRelayWorker("target2in", targetSocket, insocket);
                target2in.setDaemon(true);
                target2in.start();
            }
            System.out.println("connection closed or thread interrputed.");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (!switchToHttps) {
                try {
                    this.inconn.shutdown();
                } catch (IOException ignore) {}
            }
        }
    }
}
