#ifdef __cplusplus
extern "C" {
#endif
	
void PrintErrorMsg(DWORD err);

#ifdef __cplusplus
}
#endif
