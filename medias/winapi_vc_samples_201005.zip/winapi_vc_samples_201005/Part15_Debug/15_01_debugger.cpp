/* API����m��Windows�̎d�g�� */
/* Part 15 list x */
/* CreateProcess() + WaitForDebugEvent()�ɂ��f�o�b�K��Skelton�R�[�h */
/* cl %.cpp ..\PrintErrorMsg.obj */

#include <windows.h>
#include <stdio.h>

#include "..\PrintErrorMsg.h"

// OutputDebugString()�ŏo�͂���镶������A�f�o�b�O�Ώۃv���Z�X�̃�����
// �̈悩��R�s�[���ĕ\������B
static void onOutputDebugStringEvent(DEBUG_EVENT *dbgevt)
{
	LPOUTPUT_DEBUG_STRING_INFO pDbgInfo = &(dbgevt->u.DebugString);
	HANDLE hProcess = OpenProcess(PROCESS_VM_READ, FALSE, dbgevt->dwProcessId);
	SIZE_T rdcnt;
	if (NULL == hProcess) {
		PrintErrorMsg(GetLastError());
		return;
	}
	if (pDbgInfo->fUnicode) {
		wchar_t *buf = new wchar_t[pDbgInfo->nDebugStringLength];
		ReadProcessMemory(hProcess,
			pDbgInfo->lpDebugStringData, buf,
			pDbgInfo->nDebugStringLength * 2, &rdcnt);
		wprintf(L"[%08x]:%s\n", dbgevt->dwProcessId, buf);
		delete []buf;
	} else {
		char *buf = new char[pDbgInfo->nDebugStringLength];
		ReadProcessMemory(hProcess,
			pDbgInfo->lpDebugStringData, buf,
			pDbgInfo->nDebugStringLength * 2, &rdcnt);
		printf("[%08x]:%s\n", dbgevt->dwProcessId, buf);
		delete []buf;
	}
	CloseHandle(hProcess);
	return;
}

int main(int argc, char *argv[])
{
	if (2 != argc) {
		fprintf(stderr, "usage: %s <target>.exe\n", argv[0]);
		return -1;
	}
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si, 0, sizeof(si));
	si.cb = sizeof(si);
	if (!CreateProcess(
		NULL, // lpApplicationName
		argv[1], // lpCommandLine
		NULL, NULL, // lpProcessAttributes, lpThreadAttributes
		FALSE, // bInheritHandles
		DEBUG_PROCESS | DEBUG_ONLY_THIS_PROCESS, // dwCreationFlags
		NULL, NULL, // lpEnvironment, lpCurrentDirectory
		&si, &pi))
	{
		PrintErrorMsg(GetLastError());
		return -2;
	}

	DEBUG_EVENT dbgevt;
	DWORD buf;
	BOOL done = FALSE;
	while (!done) {
		DWORD contStatus = DBG_CONTINUE;
		WaitForDebugEvent(&dbgevt, INFINITE);
		switch (dbgevt.dwDebugEventCode) {

		case EXCEPTION_DEBUG_EVENT:
			printf("[EXCEPTION_DEBUG_EVENT]\n");
			printf("ExceptionCode = %d\n");
			buf = dbgevt.u.Exception.ExceptionRecord.ExceptionCode;
			switch (buf) {
			case EXCEPTION_BREAKPOINT:
				printf("-> BreakPoint\n");
				break;
			case EXCEPTION_INT_DIVIDE_BY_ZERO:
				printf("-> Integer divide by zero\n");
				break;
			default:
				printf("-> (Exception Code:%d)\n", buf);
			}
			printf("-> Address = %x\n", 
				dbgevt.u.Exception.ExceptionRecord.ExceptionAddress);
			break;

		case CREATE_THREAD_DEBUG_EVENT:
			printf("[CREATE_THREAD_DEBUG_EVENT]\n");
			break;
		
		case CREATE_PROCESS_DEBUG_EVENT:
			printf("[CREATE_PROCESS_DEBUG_EVENT]\n");
			break;

		case EXIT_THREAD_DEBUG_EVENT:
			printf("[EXIT_THREAD_DEBUG_EVENT]\n");
			break;

		case EXIT_PROCESS_DEBUG_EVENT:
			printf("[EXIT_PROCESS_DEBUG_EVENT]\n");
			printf("->ExitCode = %d\n", dbgevt.u.ExitProcess.dwExitCode);
			done = TRUE;
			break;

		case LOAD_DLL_DEBUG_EVENT:
			printf("[LOAD_DLL_DEBUG_EVENT]\n");
			break;

		case UNLOAD_DLL_DEBUG_EVENT:
			printf("[UNLOAD_DLL_DEBUG_EVENT]\n");
			break;

		case OUTPUT_DEBUG_STRING_EVENT:
			printf("[OUTPUT_DEBUG_STRING_EVENT]\n");
			onOutputDebugStringEvent(&dbgevt);
			break;

		case RIP_EVENT:
			printf("[RIP_EVENT]\n");
			break;

		}
		ContinueDebugEvent(dbgevt.dwProcessId, dbgevt.dwThreadId, contStatus);
	}


	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
	return 0;
}
