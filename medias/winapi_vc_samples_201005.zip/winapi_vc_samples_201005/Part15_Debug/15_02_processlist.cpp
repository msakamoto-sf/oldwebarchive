/* API����m��Windows�̎d�g�� */
/* Part 15 list 9 */
/* �V�X�e����snapshot�����v���Z�X�ꗗ��\������T���v�� */
/* cl %.cpp ..\PrintErrorMsg.obj */

#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>

#include "..\PrintErrorMsg.h"

int main(void)
{
	int rc = 0;
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (NULL == hSnapshot) {
		PrintErrorMsg(GetLastError());
		return -1;
	}
	PROCESSENTRY32 procent;
	BOOL bCont = Process32First(hSnapshot, &procent);
	while (bCont) {
		printf("ProcessId=0x%08lx, File=%s\n",
			procent.th32ProcessID, procent.szExeFile);
		bCont = Process32Next(hSnapshot, &procent);
	}
	DWORD dwErr = GetLastError();
	if (ERROR_NO_MORE_FILES != dwErr) {
		PrintErrorMsg(dwErr);
		rc = -2;
	}
	CloseHandle(hSnapshot);
	return rc;
}
