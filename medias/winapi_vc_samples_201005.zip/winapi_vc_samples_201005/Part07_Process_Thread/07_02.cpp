/* API����m��Windows�̎d�g�� */
/* Part 7 list 5 */
/* CreateProcess()��notepad���N�����AWaitForSingleObject()/GetExitCodeProcess()
�ŏI���R�[�h���擾����B */
/* cl %.cpp ..\PrintErrorMsg.obj */

#include <windows.h>
#include <stdio.h>

#include "..\PrintErrorMsg.h"

int main(void)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si, 0, sizeof(si));
	si.cb = sizeof(si);
	if (!CreateProcess(
		NULL, "notepad.exe", NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
	{
			PrintErrorMsg(GetLastError());
	} else {
		DWORD rc;
		CloseHandle(pi.hThread);
		if (WAIT_OBJECT_0 == 
			WaitForSingleObject(pi.hProcess, INFINITE))
		{
			GetExitCodeProcess(pi.hProcess, &rc);
			printf("terminate code of notepad = %lu\n", rc);
		}
		CloseHandle(pi.hProcess);
	}
	return 0;
}
