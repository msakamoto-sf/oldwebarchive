/* API����m��Windows�̎d�g�� */
/* Part 7 list 1 */
/* CreateProcess()��notepad���N������ */
/* cl %.cpp ..\PrintErrorMsg.obj */

#include <windows.h>
#include <stdio.h>

#include "..\PrintErrorMsg.h"

int main(void)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	memset(&si, 0, sizeof(si));
	si.cb = sizeof(si);
	if (!CreateProcess(
		NULL, "notepad.exe", NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
	{
			PrintErrorMsg(GetLastError());
	} else {
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	}
	return 0;
}
