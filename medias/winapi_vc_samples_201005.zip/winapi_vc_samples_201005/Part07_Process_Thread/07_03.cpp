/* API����m��Windows�̎d�g�� */
/* Part 7 list 9,10 �ȗ��� */
/* "_beginthreadex()"�ŕ����X���b�h���N�����Ă݂�B */
/* cl /MT %.cpp ..\PrintErrorMsg.obj */

#include <windows.h>
#include <stdio.h>
#include <process.h>

#include "..\PrintErrorMsg.h"

typedef struct {
	int n;
	int count;
} COUNTER;

unsigned int __stdcall countup(void *args)
{
	COUNTER *c = (COUNTER*)args;
	while (c->count < 10)
	{
		printf("Thread[%d], Count[%d]\n", c->n, c->count);
		c->count++;
		Sleep(100);
	}
	return c->count;
}

int main(void)
{
	COUNTER *args = NULL;
	int i;
	HANDLE hThread;
	unsigned int threadId;
	for (i = 0; i < 5; i++) {
		args = (COUNTER*)malloc(sizeof(COUNTER));
		if (NULL == args) {
			printf("args allocation error.\n");
			return -1;
		}
		args->n = i;
		args->count = 0;
		hThread = (HANDLE)_beginthreadex(
			NULL, 0, countup, args, 0, &threadId);
		if (0 == hThread) {
			printf("_beginthreadex() error.\n");
			return -2;
		}
		CloseHandle(hThread);
	}
	Sleep(5 * 1000);
	return 0;
}
