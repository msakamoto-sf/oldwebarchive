/* API����m��Windows�̎d�g�� */
/* Part 5 list 7 */
/* SetFilePointer()�̎g�p��B�t�@�C���ɏ����āA�擪�ɖ߂��ēǂݒ����B */
/* cl %.cpp */

#include <windows.h>
#include <stdio.h>

int main(void)
{
	HANDLE hf = CreateFile("test.dat",
		GENERIC_WRITE | GENERIC_READ,
		0, NULL, CREATE_ALWAYS, 0, NULL);
	if (INVALID_HANDLE_VALUE != hf) {
		char *data = "This is a test data.";
		char buf[256];
		DWORD written, read;
		
		WriteFile(hf, data, strlen(data), &written, NULL);
		printf("%d bytes write.\n", written);
		
		SetFilePointer(hf, 0, NULL, FILE_BEGIN);
		
		ReadFile(hf, buf, sizeof(buf), &read, NULL);
		buf[read] = '\0';
		printf("%d bytes read.\n", read);
		
		printf("%s", buf);
			
		CloseHandle(hf);
	}
	return 0;
}

