/* API����m��Windows�̎d�g�� */
/* Part 14 list 6 */
/* ���{�^���ŌŒ蕶�����Clipboard�ɃR�s�[�A
�E�{�^����(������O��)Clipboard������o�����������MessageBox()����T���v�� */
/* cl %.cpp user32.lib */
#include <windows.h>

#define MYWNDCLSNAME "MyWindowClass"

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(
	HINSTANCE hInst, 
	HINSTANCE hPrevInst, 
	LPSTR lpCmdLine, 
	int nCmdShow)
{
	WNDCLASS wndcls;
	HWND hWnd;
	MSG msg;
	ZeroMemory(&wndcls, sizeof(wndcls));
	wndcls.lpfnWndProc = WndProc;
	wndcls.hInstance = hInst;
	wndcls.hIcon = LoadIcon(0, IDI_APPLICATION);
	wndcls.hCursor = LoadCursor(0, IDC_ARROW);
	wndcls.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
	wndcls.lpszClassName = MYWNDCLSNAME;
	if (0 == RegisterClass(&wndcls)) {
		return -1;
	}
	
	hWnd = CreateWindow(
		MYWNDCLSNAME, 
		"My Window", 
		WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		0, 0, hInst, NULL);
	if (0 == hWnd) {
		return -2;
	}
	
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	
	while (GetMessage(&msg, 0, 0, 0)) {
		DispatchMessage(&msg);
	}
	
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
	case WM_LBUTTONDOWN:
		// �N���b�v�{�[�h�ɃR�s�[
		if (OpenClipboard(hWnd)) {
			EmptyClipboard(); // �N���b�v�{�[�h����ɂ���B

			char string[] = "Fixed string data";
			int len = strlen(string);
			HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, len + 1);
			if (NULL != hMem) {
				char *p = (char*)GlobalLock(hMem);
				strcpy(p, string);
				GlobalUnlock(hMem);

				SetClipboardData(CF_TEXT, hMem);

				MessageBox(hWnd, 
					"Copied. Next, click right button.", 
					"Clipboard test", 
					MB_OK | MB_ICONINFORMATION);
			}
			CloseClipboard();
		}
		return 0;

	case WM_RBUTTONDOWN:
		// �N���b�v�{�[�h����擾
		if (OpenClipboard(hWnd)) {
			HGLOBAL hGlobal;
			LPTSTR str;
			hGlobal = GetClipboardData(CF_TEXT);
			if (NULL != hGlobal) {
				str = (LPTSTR)GlobalLock(hGlobal);
				if (NULL != str) {

					MessageBox(hWnd, 
						str, 
						"Clipboard test", 
						MB_OK | MB_ICONINFORMATION);

					GlobalUnlock(hGlobal);
				}
			}
			CloseClipboard();
		}
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
