/* API����m��Windows�̎d�g�� */
/* Part 16 list xx */
/* C RunTime library (CRT) �ł�UNICODE�Ή����m�F����T���v�� */
/* cl /D _UNICODE /Fe16_03_gtrm_unicode_u.exe %.cpp */
/* cl /Fe16_03_gtrm_unicode_nou.exe %.cpp */
#include <stdio.h>
#include <string.h>
#include <tchar.h>
#include <locale.h>

int _tmain(int argc, _TCHAR *argv[])
{
	_TCHAR line[256];
	_tsetlocale(LC_ALL, _T(""));
	_getts_s(line, sizeof(line) - 1);
	_tprintf(_T("sizeof(line) = [%d]\n"), sizeof(line));
	_tprintf(_T("input = [%s], length = %d\n"), line, _tcsclen(line));
	return 0;
}
