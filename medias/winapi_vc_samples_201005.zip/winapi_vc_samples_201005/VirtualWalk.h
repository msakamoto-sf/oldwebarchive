#ifdef __cplusplus
extern "C" {
#endif

void VirtualWalk(void);

#ifdef __cplusplus
}
#endif

