/* API����m��Windows�̎d�g�� */
/* Part 10 list 10 �ȈՔ� */
/* WM_COPYDATA��M�� */
/* cl %.cpp user32.lib */
#include <windows.h>

#define MYWNDCLSNAME "MyWindowClass"
#define COPYDATA_ID_LBUTTON 100
#define COPYDATA_ID_RBUTTON 200

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(
	HINSTANCE hInst, 
	HINSTANCE hPrevInst, 
	LPSTR lpCmdLine, 
	int nCmdShow)
{
	WNDCLASS wndcls;
	HWND hWnd;
	MSG msg;
	ZeroMemory(&wndcls, sizeof(wndcls));
	wndcls.lpfnWndProc = WndProc;
	wndcls.hInstance = hInst;
	wndcls.hIcon = LoadIcon(0, IDI_APPLICATION);
	wndcls.hCursor = LoadCursor(0, IDC_ARROW);
	wndcls.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
	wndcls.lpszClassName = MYWNDCLSNAME;
	if (0 == RegisterClass(&wndcls)) {
		return -1;
	}
	
	hWnd = CreateWindow(
		MYWNDCLSNAME, 
		"10_03_recv", 
		WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		0, 0, hInst, NULL);
	if (0 == hWnd) {
		return -2;
	}
	
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	
	while (GetMessage(&msg, 0, 0, 0)) {
		DispatchMessage(&msg);
	}
	
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	COPYDATASTRUCT *pcds;

	switch (uMsg) {
	case WM_COPYDATA:
		pcds = (COPYDATASTRUCT*)lParam;
		if (COPYDATA_ID_LBUTTON == pcds->dwData) {
			MessageBox(hWnd, (LPCSTR)(pcds->lpData), "COPYDATA_ID_LBUTTON", MB_OK);
		} else if (COPYDATA_ID_RBUTTON == pcds->dwData) {
			MessageBox(hWnd, (LPCSTR)(pcds->lpData), "COPYDATA_ID_RBUTTON", MB_OK);
		} else {
			MessageBox(hWnd, "unknown dwData", "unknown", MB_OK);
		}
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
