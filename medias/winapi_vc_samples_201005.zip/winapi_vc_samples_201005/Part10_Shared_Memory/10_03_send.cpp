/* API����m��Windows�̎d�g�� */
/* Part 10 list 9 �ȈՔ� */
/* ��/�E�{�^���N���b�N��"10_03_recv"�ƌ����^�C�g���̃E�C���h�E��WM_COPYDATA���M */
/* cl %.cpp user32.lib */
#include <windows.h>

#define MYWNDCLSNAME "MyWindowClass"
#define COPYDATA_ID_LBUTTON 100
#define COPYDATA_ID_RBUTTON 200

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(
	HINSTANCE hInst, 
	HINSTANCE hPrevInst, 
	LPSTR lpCmdLine, 
	int nCmdShow)
{
	WNDCLASS wndcls;
	HWND hWnd;
	MSG msg;
	ZeroMemory(&wndcls, sizeof(wndcls));
	wndcls.lpfnWndProc = WndProc;
	wndcls.hInstance = hInst;
	wndcls.hIcon = LoadIcon(0, IDI_APPLICATION);
	wndcls.hCursor = LoadCursor(0, IDC_ARROW);
	wndcls.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
	wndcls.lpszClassName = MYWNDCLSNAME;
	if (0 == RegisterClass(&wndcls)) {
		return -1;
	}
	
	hWnd = CreateWindow(
		MYWNDCLSNAME, 
		"10_03_send", 
		WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		0, 0, hInst, NULL);
	if (0 == hWnd) {
		return -2;
	}
	
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	
	while (GetMessage(&msg, 0, 0, 0)) {
		DispatchMessage(&msg);
	}
	
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char buf1[128] = "Light Button Click";
	char buf2[128] = "Right Button Click";
	HWND hWndTgt = 0;
	COPYDATASTRUCT cds;

	switch (uMsg) {
	case WM_LBUTTONDOWN:
		hWndTgt = FindWindow(NULL, "10_03_recv");
		if (0 == hWndTgt) {
			MessageBox(hWnd, "10_03_recv not found.", "notice", MB_OK);
			return 0;
		}
		cds.dwData = COPYDATA_ID_LBUTTON;
		cds.cbData = sizeof(buf1);
		cds.lpData = buf1;
		SendMessage(hWndTgt, WM_COPYDATA, (WPARAM)hWnd, (LPARAM)&cds);
		return 0;
	case WM_RBUTTONDOWN:
		hWndTgt = FindWindow(NULL, "10_03_recv");
		if (0 == hWndTgt) {
			MessageBox(hWnd, "10_03_recv not found.", "notice", MB_OK);
			return 0;
		}
		cds.dwData = COPYDATA_ID_RBUTTON;
		cds.cbData = sizeof(buf2);
		cds.lpData = buf2;
		SendMessage(hWndTgt, WM_COPYDATA, (WPARAM)hWnd, (LPARAM)&cds);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
