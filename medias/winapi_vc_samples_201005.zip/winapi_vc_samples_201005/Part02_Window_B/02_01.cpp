/* API����m��Windows�̎d�g�� */
/* Part 2 list 2 */
/* ���C���E�C���h�E, MDI-Child, Owned�E�C���h�E������Ă݂�B */
/* cl %.cpp user32.lib */
#include <windows.h>

#define MYWNDCLSNAME "MyWindowClass"

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASS wndcls;
	HWND hWnd, hWndOwned, hWndChild;
	MSG msg;
	
	ZeroMemory(&wndcls, sizeof(wndcls));
	wndcls.lpfnWndProc = WndProc;
	wndcls.hInstance = hInst;
	wndcls.hIcon = LoadIcon(0, IDI_APPLICATION);
	wndcls.hCursor = LoadCursor(0, IDC_ARROW);
	wndcls.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
	wndcls.lpszClassName = MYWNDCLSNAME;
	if (0 == RegisterClass(&wndcls)) {
		return -1;
	}
	
	hWnd = CreateWindow(MYWNDCLSNAME, "Main Window",
		WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, 400, 200,
		0, 0, hInst, NULL);
	if (0 == hWnd) {
		return -2;
	}
	
	hWndChild = CreateWindow(MYWNDCLSNAME, "Child Window",
		WS_CHILDWINDOW | WS_CAPTION | WS_VISIBLE,
		0, 0, 200, 100,
		hWnd, 0, hInst, NULL);
	if (0 == hWndChild) {
		return -2;
	}
	
	hWndOwned = CreateWindow(MYWNDCLSNAME, "Owned Window",
		WS_POPUPWINDOW | WS_CAPTION | WS_VISIBLE,
		0, 0, 200, 100,
		hWnd, 0, hInst, NULL);
	if (0 == hWndOwned) {
		return -2;
	}
	
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	
	while (GetMessage(&msg, 0, 0, 0)) {
		DispatchMessage(&msg);
	}
	
	return msg.wParam;
}

