/* API����m��Windows�̎d�g�� */
/* Part 13 list 7 */
/* 13_01_main.exe ���~����B */
/* cl %.cpp user32.lib advapi32.lib ..\PrintErrorMsg.obj */
#include <windows.h>
#include <stdio.h>
#include "..\PrintErrorMsg.h"

#define BEEPSERVICE_NAME "BeepServices"

int main(void)
{
	SERVICE_STATUS status;

	SC_HANDLE scm = OpenSCManager(
		NULL,
		SERVICES_ACTIVE_DATABASE,
		SC_MANAGER_ALL_ACCESS);
	if (NULL == scm) {
		PrintErrorMsg(GetLastError());
		fprintf(stderr, "Unable to open SCM.\n");
		return -1;
	}
	
	SC_HANDLE svc = OpenService(scm, BEEPSERVICE_NAME, SERVICE_STOP);
	if (NULL == svc) {
		PrintErrorMsg(GetLastError());
		fprintf(stderr, "Service open FAILURE.\n");
		CloseServiceHandle(scm);
		return -2;
	}

	if (!ControlService(svc, SERVICE_CONTROL_STOP, &status)) {
		PrintErrorMsg(GetLastError());
		fprintf(stderr, "Service stop FAILURE.\n");
		CloseServiceHandle(scm);
		return -2;
	}
	CloseServiceHandle(svc);
	printf("Service stop SUCCESS.\n");
	CloseServiceHandle(scm);
	return 0;
}
