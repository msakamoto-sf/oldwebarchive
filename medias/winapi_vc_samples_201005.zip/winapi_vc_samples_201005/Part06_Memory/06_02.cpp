/* API����m��Windows�̎d�g�� */
/* Part 6 list 9 */
/* HeapAlloc()���g���ă����������蓖�Ă�T���v�� */
/* cl %.cpp ..\VirtualWalk.obj ..\PrintErrorMsg.obj */

#include <windows.h>
#include <stdio.h>

#include "..\VirtualWalk.h"
#include "..\PrintErrorMsg.h"

int main(void)
{
	VirtualWalk();

	HANDLE hh = HeapCreate(0, 0x6000, 0); // �ŏ�0x6000, �q�[�v�͊g���\�B
	if (NULL == hh) {
		PrintErrorMsg(GetLastError());
		return -1;
	}
	VirtualWalk();
	void *p1 = HeapAlloc(hh, 0, 0x7000);
	if (NULL == p1) {
		PrintErrorMsg(GetLastError());
		fprintf(stderr, "Assign Failure for 1st Block\n");
		return -1;
	}
	printf("p1 is allocated at 0x%08lx\n", p1);
	VirtualWalk();
	void *p2 = HeapAlloc(hh, 0, 0x10000);
	if (NULL == p2) {
		PrintErrorMsg(GetLastError());
		fprintf(stderr, "Assign Failure for 2nd Block\n");
		return -1;
	}
	printf("p2 is allocated at 0x%08lx\n", p2);
	VirtualWalk();

	return 0;
}

