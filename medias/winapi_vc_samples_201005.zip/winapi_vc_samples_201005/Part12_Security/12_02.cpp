/* API����m��Windows�̎d�g�� */
/* Part 12 list 2 */
/* �v���Z�X�̃A�N�Z�X�E�g�[�N���ɐݒ肳��Ă���f�t�H���gDACL��\���B
> runas /noprofile /user:(�K���ȃ��[�U�[ID) cmd
�ŊJ�����R�}���h�v�����v�g������s�����肷��Ɩʔ����B
*/
/* cl %.cpp user32.lib advapi32.lib ..\PrintErrorMsg.obj */
#include <windows.h>
#include <sddl.h>
#include <stdio.h>

#include "..\PrintErrorMsg.h"

struct SIDTYPENAME
{
	SID_NAME_USE type;
	const char *name;
} nametbl[] = {
	{ SidTypeUser, "USER" },
	{ SidTypeGroup, "GROUP" },
	{ SidTypeDomain, "DOMAIN" },
	{ SidTypeAlias, "ALIAS" },
	{ SidTypeWellKnownGroup, "WELL KNOWN GROUP" },
	{ SidTypeDeletedAccount, "DELETED ACCOUNT" },
	{ SidTypeInvalid, "INVALID" },
	{ SidTypeComputer, "COMPUTER" },
	{ SidTypeUnknown, NULL }
};

void printSIDType(SID_NAME_USE use)
{
	SIDTYPENAME *ptr = nametbl;
	while (NULL != ptr->name) {
		if (use == ptr->type) {
			printf(ptr->name);
			return;
		}
		ptr++;
	}
	printf("UNKNOWN");
}

void printAccessMask(DWORD mask)
{
	if (GENERIC_READ & mask) printf("GENERIC_READ ");
	if (GENERIC_WRITE & mask) printf("GENERIC_WRITE ");
	if (GENERIC_EXECUTE & mask) printf("GENERIC_EXECUTE ");
	if (GENERIC_ALL & mask) printf("GENERIC_ALL ");
}

int main(void)
{
	printf("--- Current Default DACL ---\n");
	HANDLE hToken = NULL;
	int result = 0;

	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_READ, &hToken)) {
		PrintErrorMsg(GetLastError());
		printf("OpenProcessToken() failed\n");
		result = -1;
		goto exit_handler;
	}

	char buffer[1024];
	TOKEN_DEFAULT_DACL *pDefdacl = (TOKEN_DEFAULT_DACL*)buffer;
	DWORD retlen = 0;
	if (!GetTokenInformation(hToken, TokenDefaultDacl, 
	pDefdacl, sizeof(buffer), &retlen)) {
		PrintErrorMsg(GetLastError());
		printf("GetTokenInformation() failed\n");
		result = -2;
		goto exit_handler;
	}

	if (NULL == pDefdacl->DefaultDacl) {
		printf("There's no dfeault dacl.\n");
		goto exit_handler;
	}
	
	int count = pDefdacl->DefaultDacl->AceCount;
	printf("Number of ACEs: %d\n\n", count);

	ACE_HEADER *pHdr = (ACE_HEADER*)&pDefdacl->DefaultDacl[1];
	for (int i = 0; i < count; i++) {
		if (pHdr->AceType == ACCESS_ALLOWED_ACE_TYPE ||
			pHdr->AceType == ACCESS_DENIED_ACE_TYPE)
		{
			ACCESS_ALLOWED_ACE *pHdr2 = (ACCESS_ALLOWED_ACE*)pHdr;
			
			printf("ACE type: ");
			if (ACCESS_ALLOWED_ACE_TYPE == pHdr->AceType) {
				printf("Allowed ACE\n");
			} else {
				printf("Denied ACE\n");
			}
			
			printf("Access mask: ");
			printAccessMask(pHdr2->Mask);
			printf("\n");
			
			LPTSTR sidstr;
			if (ConvertSidToStringSid(
				(PSID)&pHdr2->SidStart, &sidstr))
			{
				printf("SID: %s\n", sidstr);
				LocalFree(sidstr);
			}
			
			char name[128], domain[128];
			DWORD namelen = sizeof(name);
			DWORD domlen = sizeof(domain);
			SID_NAME_USE use;
			if (LookupAccountSid(NULL, (PSID)&pHdr2->SidStart, 
				name, &namelen, domain, &domlen, &use))
			{
				printf("name: %s\n", name);
				printf("type: ");
				printSIDType(use);
				printf("\n");
			} else {
				printf("Cannot print a name and a type.\n");
			}
		} else {
			printf("Other type of ACE\n");
		}
		printf("\n");
		pHdr = (ACE_HEADER*)((char*)pHdr + pHdr->AceSize);
	}

exit_handler:
	if (NULL != hToken) CloseHandle(hToken);
	return result;
}
