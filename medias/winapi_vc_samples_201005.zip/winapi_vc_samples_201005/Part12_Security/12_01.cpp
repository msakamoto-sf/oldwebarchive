/* API����m��Windows�̎d�g�� */
/* Part 12 list 1 */
/* ���[�U�[ID/�O���[�vID�ɑ΂���SID�𕶎���Ƃ��ĕ\������B */
/* cl %.cpp user32.lib advapi32.lib */
#include <windows.h>
#include <sddl.h>
#include <stdio.h>

struct SIDTYPENAME
{
	SID_NAME_USE type;
	const char *name;
} nametbl[] = {
	{ SidTypeUser, "USER" },
	{ SidTypeGroup, "GROUP" },
	{ SidTypeDomain, "DOMAIN" },
	{ SidTypeAlias, "ALIAS" },
	{ SidTypeWellKnownGroup, "WELL KNOWN GROUP" },
	{ SidTypeDeletedAccount, "DELETED ACCOUNT" },
	{ SidTypeInvalid, "INVALID" },
	{ SidTypeComputer, "COMPUTER" },
	{ SidTypeUnknown, NULL }
};

void printSIDType(SID_NAME_USE use)
{
	SIDTYPENAME *ptr = nametbl;
	while (NULL != ptr->name) {
		if (use == ptr->type) {
			printf(ptr->name);
			return;
		}
		ptr++;
	}
	printf("UNKNOWN");
}

int main(int argc, char **argv)
{
	if (argc < 2) {
		fprintf(stderr, "Usage: %s <user or group id>\n", argv[0]);
		return -1;
	}
	
	int rc = -1;
	
	char sidBuf[256];
	SID *pSid = (SID*)sidBuf;
	DWORD sidLen = sizeof(sidBuf);
	char domBuf[256];
	LPTSTR domName = (LPTSTR)domBuf;
	DWORD domLen = sizeof(domBuf);
	SID_NAME_USE use;
	if (LookupAccountName(
		NULL, argv[1], pSid, &sidLen, domName, &domLen, &use))
	{
		LPTSTR sidString;
		if (ConvertSidToStringSid(pSid, &sidString)) {
			printf("SID: %s\n", sidString);
			printf("Domain: %s\n", domName);
			printf("Type: ");
			printSIDType(use);
			LocalFree(sidString);
			rc = 0;
		}
	}
	if (0 != rc) {
		fprintf(stderr, "Error: %lu\n", GetLastError());
	}
	return 0;
}
