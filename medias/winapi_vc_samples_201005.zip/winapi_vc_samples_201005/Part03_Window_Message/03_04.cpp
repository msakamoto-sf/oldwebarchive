/* API����m��Windows�̎d�g�� */
/* Part 3 list 9 �ȗ��� */
/* Get�ł͂Ȃ�PeekMessage()���g���A���b�Z�[�W�������A�C�h����Ԃŏ���
�{�Ǝ��̃��b�Z�[�W���`���ASendMessage()/PostMessage()�������B */
/* cl %.cpp user32.lib */
#include <stdio.h>
#include <windows.h>

#define MYWNDCLSNAME "MyWindowClass"
#define MYWNDMSG "MyWindowMessage"

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int timer_count;
char buf[1024];
#define TIMER_LIMIT 1000

UINT WM_MYMSG;

int WINAPI WinMain(
	HINSTANCE hInst, 
	HINSTANCE hPrevInst, 
	LPSTR lpCmdLine, 
	int nCmdShow)
{
	WNDCLASS wndcls;
	HWND hWnd;
	MSG msg;
	ZeroMemory(&wndcls, sizeof(wndcls));
	wndcls.lpfnWndProc = WndProc;
	wndcls.hInstance = hInst;
	wndcls.hIcon = LoadIcon(0, IDI_APPLICATION);
	wndcls.hCursor = LoadCursor(0, IDC_ARROW);
	wndcls.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
	wndcls.lpszClassName = MYWNDCLSNAME;
	if (0 == RegisterClass(&wndcls)) {
		return -1;
	}
	
	hWnd = CreateWindow(
		MYWNDCLSNAME, 
		"My Window", 
		WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		0, 0, hInst, NULL);
	if (0 == hWnd) {
		return -2;
	}

	WM_MYMSG = RegisterWindowMessage(MYWNDMSG);
	if (0 == WM_MYMSG) {
		return -3;
	}
	
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	timer_count = 0;
	while (1) {
		if (PeekMessage(&msg, 0, 0, 0, PM_REMOVE)) {
			if (WM_QUIT == msg.message) {
				break;
			}
			DispatchMessage(&msg);
		} else {
			if (TIMER_LIMIT > timer_count) {
				SendMessage(hWnd, WM_MYMSG, (WPARAM)0, (LPARAM)0);
				//PostMessage(hWnd, WM_MYMSG, (WPARAM)0, (LPARAM)0);
			}
		}
	}
	
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (WM_MYMSG == uMsg) {
		timer_count++;
		sprintf_s(buf, 1024, "TIMER count = %d\n", timer_count);
		SetWindowText(hWnd, buf);
		return 0;
	}
	switch (uMsg) {
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
