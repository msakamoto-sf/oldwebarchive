/* API����m��Windows�̎d�g�� */
/* Part 3 list 4 �ȗ��� */
/* SetTimer()���g�����^�C�}�[�����̗� */
/* cl %.cpp user32.lib */
#include <stdio.h>
#include <windows.h>

#define MYWNDCLSNAME "MyWindowClass"
#define MYTIMERID 1000

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int timer_count;
char buf[1024];
#define TIMER_LIMIT 100

int WINAPI WinMain(
	HINSTANCE hInst, 
	HINSTANCE hPrevInst, 
	LPSTR lpCmdLine, 
	int nCmdShow)
{
	WNDCLASS wndcls;
	HWND hWnd;
	MSG msg;
	ZeroMemory(&wndcls, sizeof(wndcls));
	wndcls.lpfnWndProc = WndProc;
	wndcls.hInstance = hInst;
	wndcls.hIcon = LoadIcon(0, IDI_APPLICATION);
	wndcls.hCursor = LoadCursor(0, IDC_ARROW);
	wndcls.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
	wndcls.lpszClassName = MYWNDCLSNAME;
	if (0 == RegisterClass(&wndcls)) {
		return -1;
	}
	
	hWnd = CreateWindow(
		MYWNDCLSNAME, 
		"My Window", 
		WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		0, 0, hInst, NULL);
	if (0 == hWnd) {
		return -2;
	}
	
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	timer_count = 0;
	if (0 == SetTimer(hWnd, MYTIMERID, 100, (TIMERPROC)NULL)) {
		return -3;
	}
	
	while (GetMessage(&msg, 0, 0, 0)) {
		DispatchMessage(&msg);
	}
	
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
	case WM_TIMER:
		if (TIMER_LIMIT > timer_count) {
			timer_count++;
			sprintf_s(buf, 1024, "TIMER ID:%d, count = %d\n", (UINT)wParam, timer_count);
			SetWindowText(hWnd, buf);
		} else {
			timer_count = 0;
			KillTimer(hWnd, MYTIMERID);
		}
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
