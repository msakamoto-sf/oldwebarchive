// DialogBox()���g���āA���\�[�X�Ɋi�[�����_�C�A���O�{�b�N�X��\������T���v��
// > cl dialogbox_res01.c user32.lib dialogbox_res01.res
#include <windows.h>
#include "resource.h"

char szItemName[1024];

BOOL CALLBACK DialogProc(
	HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{ 
	switch (uMsg) {
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDOK:
			if (!GetDlgItemText(hWnd, IDC_EDIT1, szItemName, 256)) {
				*szItemName = 0;
			}
		case IDCANCEL:
			EndDialog(hWnd, wParam);
			return TRUE;
		}
	} 
	return FALSE;
}

int main(int argc, char *argv[])
{
	HWND hWndDesktop = NULL;
	HINSTANCE hCurrentInst = NULL;
	UINT_PTR uDlgRet = 0;

	hCurrentInst = GetModuleHandle(NULL);
	hWndDesktop = GetDesktopWindow();
	uDlgRet = DialogBox(hCurrentInst, MAKEINTRESOURCE(IDD_DIALOG1), hWndDesktop, (DLGPROC)DialogProc);
	MessageBox(hWndDesktop, szItemName, "Input Text", MB_OK);
	if (IDOK == uDlgRet) {
		MessageBox(hWndDesktop, "OK", "Caption", MB_OK);
	} else {
		MessageBox(hWndDesktop, "Cancel", "Caption", MB_OK);
	}
	return 0;
}
