#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDR_MENU1                               100
#define IDM_FILE_OPEN                           40000
#define IDM_FILE_SAVE                           40001
#define IDM_FILE_EXIT                           40003
#define IDM_HELP_VERSION                        40004
