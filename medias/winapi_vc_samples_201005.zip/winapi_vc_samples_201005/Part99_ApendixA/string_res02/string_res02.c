// FindResource()/FindResourceEx()���g���ĕ����񃊃\�[�X�́u�u���b�N�v��
// �擾���A�_���v����T���v��
// > cl string_res02.c user32.lib string_res02.res
#include <windows.h>
#include <stdio.h>

#include "resource.h"

void PrintErrorMsg(DWORD err)
{
	LPTSTR lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER
		| FORMAT_MESSAGE_FROM_SYSTEM 
		| FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL, err,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("%s\n", lpMsgBuf);
	LocalFree(lpMsgBuf);
}

int main(int argc, char *argv[])
{
	HINSTANCE hCurrentInst;
	HRSRC hResRc;
	HGLOBAL hGlobal;
	DWORD dwSizeofRes;
	char *buf = NULL;
	WORD wBlockID;
	int i;

	hCurrentInst = GetModuleHandle(NULL);

	// see : http://support.microsoft.com/kb/q196774/EN-US/
	wBlockID = IDS_STRING1 / 16 + 1;
/*
	hResRc = FindResourceEx(
		hCurrentInst, 
		RT_STRING, 
		MAKEINTRESOURCE(wBlockID), 
//		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT)
		MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US)
//		MAKELANGID(LANG_JAPANESE, SUBLANG_JAPANESE_JAPAN)
	);
*/
	hResRc = FindResource(
		hCurrentInst, 
		MAKEINTRESOURCE(wBlockID),
		RT_STRING);
	if (NULL == hResRc) {
		PrintErrorMsg(GetLastError());
		return -1;
	}

	dwSizeofRes = SizeofResource(hCurrentInst, hResRc);
	if (0 == dwSizeofRes) {
		PrintErrorMsg(GetLastError());
		return -2;
	}
	printf("size = %d\n", dwSizeofRes);
	
	hGlobal = LoadResource(hCurrentInst, hResRc);
	if (NULL == hGlobal) {
		PrintErrorMsg(GetLastError());
		return -3;
	}

	buf = (char*)LockResource(hGlobal);
	if (NULL == buf) {
		PrintErrorMsg(GetLastError());
		return -4;
	}
	for (i = 0; i < dwSizeofRes; i++, buf++) {
		printf("dump[%i] = %x\n", i, *buf);
	}

	return 0;
}

