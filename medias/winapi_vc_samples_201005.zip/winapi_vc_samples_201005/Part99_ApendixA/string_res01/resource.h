#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDS_STRING1                             40000
#define IDS_STRING2                             40001
