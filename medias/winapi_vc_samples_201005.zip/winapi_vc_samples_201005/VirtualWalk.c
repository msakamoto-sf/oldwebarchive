/* API����m��Windows�̎d�g�� */
/* Part 6 list 3 */
/* ���z�A�h���X�̃y�[�W��Ԃ��ꗗ�\������֐� */
/* cl /c %.c */

#include <windows.h>
#include <stdio.h>

#include "VirtualWalk.h"

void VirtualWalk(void)
{
	unsigned char *p = (unsigned char*)0x0;
	MEMORY_BASIC_INFORMATION mbi;
	
	printf("Address, Size(bytes), Status, Access Limit\n");
	printf("--------------------------------------------\n");
	while (1) {
		if (VirtualQuery(p, &mbi, sizeof(mbi))) {
			printf("0x%08lx, 0x%08lx, ", 
				mbi.BaseAddress,
				mbi.RegionSize
			);
			switch (mbi.State) {
			case MEM_COMMIT:
				printf("commit,");
				break;
			case MEM_RESERVE:
				printf("reserve,");
				break;
			case MEM_FREE:
				printf("free,");
				break;
			default:
				printf(",");
			}
			
			switch (mbi.Protect) {
			case PAGE_NOACCESS:
				printf("Hidden");
				break;
			case PAGE_READONLY:
				printf("ReadOnly");
				break;
			case PAGE_READWRITE:
				printf("ReadWrite");
				break;
			case PAGE_WRITECOPY:
				printf("CopyOnWrite");
				break;
			case PAGE_EXECUTE:
				printf("Executable");
				break;
			case PAGE_EXECUTE_READ:
				printf("ExecutableReadOnly");
				break;
			case PAGE_EXECUTE_READWRITE:
				printf("ExecutableReadWrite");
				break;
			case PAGE_EXECUTE_WRITECOPY:
				printf("ExecutableCopyOnWrite");
				break;
			default:
				break;
			}
			
			printf("\n");
			
			p = (unsigned char*)mbi.BaseAddress + mbi.RegionSize;
			if (p == 0) {
				break;
			}
		} else {
			printf("%0x%08lx -- Access Denied\n");
			break;
		}
	}
	printf("--------------------------------------------\n\n");
}
