/* API����m��Windows�̎d�g�� */
/* Part 17 list xx */
/* Font�I��DialogBox + TextOut()�̃T���v�� */
/* > rc fonttest.rc */
/* > cl (/D UNICODE /D _UNICODE) %.cpp user32.lib comdlg32.lib gdi32.lib fonttest.res */
#include <windows.h>
#include <windowsx.h>
#include <string.h>
#include <tchar.h>

#include "resource.h"

#define MYWNDCLSNAME (_T("MyWindowClass"))

// �O��̒l���O���[�o���ϐ��Ɋo���Ă����B
LOGFONT g_logfont;

// �}�E�X�N���b�N���ꂽ���W���o���Ă����B
int lbutton_x;
int lbutton_y;

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int WINAPI _tWinMain(
	HINSTANCE hInst, 
	HINSTANCE hPrevInst, 
	LPTSTR lpCmdLine, 
	int nCmdShow)
{
	WNDCLASS wndcls;
	HWND hWnd;
	MSG msg;
	ZeroMemory(&wndcls, sizeof(wndcls));
	wndcls.lpfnWndProc = WndProc;
	wndcls.hInstance = hInst;
	wndcls.hIcon = LoadIcon(0, IDI_APPLICATION);
	wndcls.hCursor = LoadCursor(0, IDC_ARROW);
	wndcls.hbrBackground = (HBRUSH)COLOR_BACKGROUND;
	
	// ���j���[���\�[�X���w��
	wndcls.lpszMenuName =  MAKEINTRESOURCE(IDR_MENU1);

	wndcls.lpszClassName = MYWNDCLSNAME;
	if (0 == RegisterClass(&wndcls)) {
		return -1;
	}
	
	hWnd = CreateWindow(
		MYWNDCLSNAME, 
		_T("�t�H���g�e�X�g"), 
		WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		CW_USEDEFAULT, CW_USEDEFAULT, 
		0, 0, hInst, NULL);
	if (0 == hWnd) {
		return -2;
	}
	
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	
	while (GetMessage(&msg, 0, 0, 0)) {
		DispatchMessage(&msg);
	}
	
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDM_CHOOSEFONT1:
			if (g_logfont.lfFaceName[0] != _T('\0')) {
				HDC hdc = GetDC(hWnd);
				HFONT fnt = (HFONT)GetCurrentObject(hdc, OBJ_FONT);
				if (0 != fnt) {
					GetObject(fnt, sizeof(g_logfont), &g_logfont);
				}
				ReleaseDC(hWnd, hdc);
			}
			
			// �t�H���g�I��DLG��\��
			CHOOSEFONT chfnt;
			ZeroMemory(&chfnt, sizeof(chfnt));
			chfnt.lStructSize = sizeof(chfnt);
			chfnt.hwndOwner = hWnd;
			chfnt.Flags = CF_SCREENFONTS | CF_INITTOLOGFONTSTRUCT;
			chfnt.lpLogFont = &g_logfont;
			chfnt.nFontType = SCREEN_FONTTYPE;
			if (0 != ChooseFont(&chfnt)) {
				MessageBox(hWnd, g_logfont.lfFaceName, _T("Face Name"), MB_OK);
			}
			break;
		case IDM_EXIT1:
			PostQuitMessage(0);
			break;
		} 
		return 0;
	case WM_PAINT:
		{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);

		HFONT fnt = CreateFontIndirect(&g_logfont);
		HFONT fntOrig = (HFONT)SelectObject(hdc, fnt);
		
		// �������`��
		TCHAR msg[] = _T("�t�H���g�\���̎���");
		TextOut(hdc, lbutton_x, lbutton_y, msg, _tcsclen(msg));
		
		SelectObject(hdc, fntOrig);
		DeleteObject(fnt);
		EndPaint(hWnd, &ps);
		}
		return 0;
	case WM_LBUTTONDOWN:
		lbutton_x = GET_X_LPARAM(lParam);
		lbutton_y = GET_Y_LPARAM(lParam);
		InvalidateRect(hWnd, NULL, TRUE);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
