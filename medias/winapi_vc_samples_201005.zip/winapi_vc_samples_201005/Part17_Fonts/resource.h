#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDR_MENU1                               100
#define IDM_CHOOSEFONT1                         40000
#define IDM_EXIT1                               40001
