import sys, logging, struct, ctypes

# {{{ data structure definitions

BYTE = ctypes.c_ubyte
WORD = ctypes.c_ushort
LONG = ctypes.c_long
DWORD = ctypes.c_ulong
RVA = ctypes.c_ulong

class IMAGE_DOS_HEADER(ctypes.Structure):
  _fields_ = [
      ('e_magic', WORD), # Magic number
      ('e_cblp', WORD), # Bytes on last page of file
      ('e_cp', WORD), # Pages in file
      ('e_crlc', WORD), # Relocations
      ('e_cparhdr', WORD), # Size of header in paragraphs
      ('e_minalloc', WORD), # Minimum extra paragraphs needed
      ('e_maxalloc', WORD), # Maximum extra paragraphs needed
      ('e_ss', WORD), # Initial (relative) SS value
      ('e_sp', WORD), # Initial SP value
      ('e_csum', WORD), # Checksum
      ('e_ip', WORD), # Initial IP value
      ('e_cs', WORD), # Initial (relative) CS value
      ('e_lfarlc', WORD), # File address of relocation table
      ('e_ovno', WORD), # Overlay number
      ('e_res', WORD * 4), # Reserved words
      ('e_oemid', WORD), # OEM identifier (for e_oeminfo)
      ('e_oeminfo', WORD), # OEM information; e_oemid specific
      ('e_res2', WORD * 10), # Reserved words
      ('e_lfanew', LONG), # File address of new exe header
      ]

class IMAGE_FILE_HEADER(ctypes.Structure):
  _fields_ = [
      ('Machine', WORD),
      ('NumberOfSections', WORD),
      ('TimeDateStamp', DWORD),
      ('PointerToSymbolTable', DWORD),
      ('NumberOfSymbols', DWORD),
      ('SizeOfOptionalHeader', WORD),
      ('Characteristics', WORD),
      ]

class IMAGE_DATA_DIRECTORY(ctypes.Structure):
  _fields_ = [
      ('VirtualAddress', DWORD),
      ('Size', DWORD),
      ]

IMAGE_NUMBEROF_DIRECTORY_ENTRIES = 16

IMAGE_DIRECTORY_ENTRY_EXPORT         =  0 #  Export Directory
IMAGE_DIRECTORY_ENTRY_IMPORT         =  1 #  Import Directory
IMAGE_DIRECTORY_ENTRY_RESOURCE       =  2 #  Resource Directory
IMAGE_DIRECTORY_ENTRY_EXCEPTION      =  3 #  Exception Directory
IMAGE_DIRECTORY_ENTRY_SECURITY       =  4 #  Security Directory
IMAGE_DIRECTORY_ENTRY_BASERELOC      =  5 #  Base Relocation Table
IMAGE_DIRECTORY_ENTRY_DEBUG          =  6 #  Debug Directory
IMAGE_DIRECTORY_ENTRY_ARCHITECTURE   =  7 #  Architecture Specific Data
IMAGE_DIRECTORY_ENTRY_GLOBALPTR      =  8 #  RVA of GP
IMAGE_DIRECTORY_ENTRY_TLS            =  9 #  TLS Directory
IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG    = 10 #  Load Configuration Directory
IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT   = 11 #  Bound Import Directory in headers
IMAGE_DIRECTORY_ENTRY_IAT            = 12 #  Import Address Table
IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT   = 13 #  Delay Load Import Descriptors
IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR = 14 #  COM Runtime descriptor


class IMAGE_OPTIONAL_HEADER(ctypes.Structure):
  _fields_ = [
      ('Magic', WORD),
      ('MajorLinkerVersion', BYTE),
      ('MinorLinkerVersion', BYTE),
      ('SizeOfCode', DWORD),
      ('SizeOfInitializedData', DWORD),
      ('SizeOfUninitializedData', DWORD),
      ('AddressOfEntryPoint', DWORD),
      ('BaseOfCode', DWORD),
      ('BaseOfData', DWORD),
      ('ImageBase', DWORD),
      ('SectionAlignment', DWORD),
      ('FileAlignment', DWORD),
      ('MajorOperatingSystemVersion', WORD),
      ('MinorOperatingSystemVersion', WORD),
      ('MajorImageVersion', WORD),
      ('MinorImageVersion', WORD),
      ('MajorSubsystemVersion', WORD),
      ('MinorSubsystemVersion', WORD),
      ('Win32VersionValue', DWORD),
      ('SizeOfImage', DWORD),
      ('SizeOfHeaders', DWORD),
      ('CheckSum', DWORD),
      ('Subsystem', WORD),
      ('DllCharacteristics', WORD),
      ('SizeOfStackReserve', DWORD),
      ('SizeOfStackCommit', DWORD),
      ('SizeOfHeapReserve', DWORD),
      ('SizeOfHeapCommit', DWORD),
      ('LoaderFlags', DWORD),
      ('NumberOfRvaAndSizes', DWORD),
      ('DataDirectory', IMAGE_DATA_DIRECTORY * IMAGE_NUMBEROF_DIRECTORY_ENTRIES ),
      ]

class IMAGE_NT_HEADERS(ctypes.Structure):
  _fields_ = [
      ('Signature', DWORD),
      ('FileHeader', IMAGE_FILE_HEADER),
      ('OptionalHeader', IMAGE_OPTIONAL_HEADER),
      ]

IMAGE_SIZEOF_SHORT_NAME = 8

class IMAGE_SECTION_HEADER_MISC(ctypes.Union):
  _fields_ = [
      ('PhysicalAddress', DWORD),
      ('VirtualSize', DWORD),
      ]

class IMAGE_SECTION_HEADER(ctypes.Structure):
  _fields_ = [
      ('Name', BYTE * IMAGE_SIZEOF_SHORT_NAME),
      ('Misc', IMAGE_SECTION_HEADER_MISC),
      ('VirtualAddress', DWORD),
      ('SizeOfRawData', DWORD),
      ('PointerToRawData', DWORD),
      ('PointerToRelocations', DWORD),
      ('PointerToLinenumbers', DWORD),
      ('NumberOfRelocations', WORD),
      ('NumberOfLinenumbers', WORD),
      ('Characteristics', DWORD),
      ]

class IMAGE_IMPORT_DESCRIPTOR_MISC(ctypes.Union):
  _fields_ = [
      # 0 for terminating null import descriptor
      ('Characteristics', DWORD), 
      #  RVA to original unbound IAT (PIMAGE_THUNK_DATA)
      ('OriginalFirstThunk', DWORD), 
      ]

class IMAGE_IMPORT_DESCRIPTOR(ctypes.Structure):
  _fields_ = [
      ('Misc', IMAGE_IMPORT_DESCRIPTOR_MISC),
      # 0 if not bound,
      # -1 if bound, and real date/time stamp
      #     in IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT (new BIND)
      # O.W. date/time stamp of DLL bound to (Old BIND)
      ('TimeDateStamp', DWORD),
      ('ForwarderChain', DWORD), # -1 if no forwarders
      ('Name', DWORD), 
      # RVA to IAT (if bound this IAT has actual addresses)
      ('FirstThunk', DWORD), 
      ]


class IMAGE_IMPORT_BY_NAME(ctypes.Structure):
  _fields_ = [
      ('Hint', WORD),
      ('Name', BYTE),
      ]

class IMAGE_THUNK_DATA(ctypes.Union):
  _fields_ = [
      ('ForwarderString', DWORD), # PBYTE
      ('Function', DWORD), # PDWORD
      ('Ordinal', DWORD), 
      ('AddressOfData', DWORD), # PIMAGE_IMPORT_BY_NAME
      ]

IMAGE_ORDINAL_FLAG64 = 0x8000000000000000
IMAGE_ORDINAL_FLAG32 = 0x80000000

def IMAGE_ORDINAL64(Ordinal):
  return (Ordinal & 0xffff)

def IMAGE_ORDINAL32(Ordinal):
  return (Ordinal & 0xffff)

def IMAGE_SNAP_BY_ORDINAL64(Ordinal):
  return ((Ordinal & IMAGE_ORDINAL_FLAG64) != 0)

def IMAGE_SNAP_BY_ORDINAL32(Ordinal):
  return ((Ordinal & IMAGE_ORDINAL_FLAG32) != 0)

class IMAGE_EXPORT_DIRECTORY(ctypes.Structure):
  _fields_ = [
      ('Characteristics', DWORD),
      ('TimeDateStamp', DWORD),
      ('MajorVersion', WORD),
      ('MinorVersion', WORD),
      ('Name', DWORD),
      ('Base', DWORD),
      ('NumberOfFunctions', DWORD),
      ('NumberOfNames', DWORD),
      ('AddressOfFunctions', DWORD),
      ('AddressOfNames', DWORD),
      ('AddressOfNameOrdinals', DWORD),
      ]

class IMAGE_BOUND_IMPORT_DESCRIPTOR(ctypes.Structure):
  _fields_ = [
      ('TimeDateStamp', DWORD),
      ('OffsetModuleName', WORD),
      ('NumberOfModuleForwarderRefs', WORD),
      # Array of zero or more IMAGE_BOUND_FORWARDER_REF follows
      ]

class IMAGE_BOUND_FORWARDER_REF(ctypes.Structure):
  _fields_ = [
      ('TimeDateStamp', DWORD),
      ('OffsetModuleName', WORD),
      ('Reserved', WORD),
      ]

class ImgDelayDescr(ctypes.Structure):
  _fields_ = [
      ('grAttrs', DWORD),
      ('rvaDLLName', RVA),
      ('rvaHmod', RVA),
      ('rvaIAT', RVA),
      ('rvaINT', RVA),
      ('rvaBoundIAT', RVA),
      ('rvaUnloadIAT', RVA),
      ('dwTimeStamp', DWORD),
      ]

class IMAGE_BASE_RELOCATION(ctypes.Structure):
  _fields_ = [
      ('VirtualAddress', DWORD),
      ('SizeOfBlock', DWORD),
      # ('TypeOffset', WORD * ?),
      ]

IMAGE_REL_BASED_ABSOLUTE       = 0
IMAGE_REL_BASED_HIGH           = 1
IMAGE_REL_BASED_LOW            = 2
IMAGE_REL_BASED_HIGHLOW        = 3
IMAGE_REL_BASED_HIGHADJ        = 4
IMAGE_REL_BASED_MIPS_JMPADDR   = 5
IMAGE_REL_BASED_MIPS_JMPADDR16 = 9
IMAGE_REL_BASED_IA64_IMM64     = 9
IMAGE_REL_BASED_DIR64          = 10

IMAGE_REL_BAESD_TYPES = [
    'ABSOLUTE',       # 0
    'HIGH',           # 1
    'LOW',            # 2
    'HIGHLOW',        # 3
    'HIGHADJ',        # 4
    'MIPS_JMPADDR',   # 5
    'UNKNOWN',        # 6
    'UNKNOWN',        # 7
    'UNKNOWN',        # 8
    'MIPS_JMPADDR16 or IA64_IMM64', # 9
    'DIR64',          # 10
    ]

# }}}

if 2 != len(sys.argv):
  print 'usage: python %s filename' % sys.argv[0]
  quit()

file_name = sys.argv[1]

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s %(name)s %(levelname)s %(message)s',
    )
log = logging.getLogger('main')

try:
  f = open(file_name, 'rb')
except IOError, e:
  log.error("open(%s) faileed." % file_name)
  log.error(e)
  raise e

#  read IMAGE_DOS_HEADER

f.seek(0, 0)
sz = ctypes.sizeof(IMAGE_DOS_HEADER)
data = f.read(sz)
dos_header = IMAGE_DOS_HEADER()
fit = min(len(data), sz)
ctypes.memmove(ctypes.addressof(dos_header), data, fit)

#  read IMAGE_NT_HEADERS

f.seek(dos_header.e_lfanew, 0)
sz = ctypes.sizeof(IMAGE_NT_HEADERS)
data = f.read(sz)
pe_header = IMAGE_NT_HEADERS()
fit = min(len(data), sz)
ctypes.memmove(ctypes.addressof(pe_header), data, fit)

file_header = pe_header.FileHeader
opt_header = pe_header.OptionalHeader

# enumerate IMAGE_SECTION_HEADER array
section_headers = []
section_header_sz = ctypes.sizeof(IMAGE_SECTION_HEADER)
for i in range(file_header.NumberOfSections):
  data = f.read(section_header_sz)
  section_header = IMAGE_SECTION_HEADER()
  fit = min(len(data), sz)
  ctypes.memmove(ctypes.addressof(section_header), data, fit)
  section_headers.append(section_header)

# load to memory
f.seek(0, 0)
file_bytes = f.read() # read all file contents
image_buf = ctypes.create_string_buffer(opt_header.SizeOfImage)
ctypes.memset(image_buf, 0, opt_header.SizeOfImage)
image_buf_ptr = ctypes.addressof(image_buf)

# copy headers
ctypes.memmove(
    image_buf_ptr, 
    file_bytes,
    opt_header.SizeOfHeaders
    )

# copy section datas
for h in section_headers:
  section_virtual_addr = h.VirtualAddress
  pointer_to_rawdata = h.PointerToRawData
  size_of_rawdata = h.SizeOfRawData
  if pointer_to_rawdata :
    ctypes.memmove(
        image_buf_ptr + section_virtual_addr,
        file_bytes[pointer_to_rawdata:pointer_to_rawdata + size_of_rawdata],
        size_of_rawdata)

# Base Relocations
br_entry = opt_header.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC]
br_rva = br_entry.VirtualAddress
br_head = image_buf_ptr + br_rva
br_tail = br_head + br_entry.Size

if 0 == br_rva:
  print "NO BASE RELOCATIONS"
  quit()

br_sz = ctypes.sizeof(IMAGE_BASE_RELOCATION)
br_type_sz = ctypes.sizeof(WORD)
offset = br_head
brs = []
while 1:
  br = IMAGE_BASE_RELOCATION()
  ctypes.memmove(
      ctypes.addressof(br),
      offset,
      br_sz)
  br.types = []
  offset = offset + br_sz
  br_types_num = (br.SizeOfBlock - br_sz) / br_type_sz
  for i in xrange(br_types_num):
    br_type = WORD()
    ctypes.memmove(
        ctypes.addressof(br_type),
        offset,
        br_type_sz)
    offset = offset + br_type_sz
    br.types.append(br_type)
  brs.append(br)
  if offset + 1 > br_tail:
    break

for br in brs:
  print "-----------------"
  print "VirtualAddress = 0x%08X" % br.VirtualAddress
  print "SizeOfBlock = 0x%08X" % br.SizeOfBlock
  print "\t[TYPE],\t[OFFSET],\t[FILE VALUE]"
  for br_type in br.types:
    rel_base_type = (0xF000 & br_type.value) >> 12
    rel_base_offset = 0xFFF & br_type.value
    file_value = DWORD()
    ctypes.memmove(
        ctypes.addressof(file_value),
        image_buf_ptr + br.VirtualAddress + rel_base_offset,
        ctypes.sizeof(DWORD))
    print "\t%s,\t%X h,\t%X" % (
        IMAGE_REL_BAESD_TYPES[rel_base_type], 
        rel_base_offset,
        file_value.value
        )


