#include <stdio.h>

int __declspec(dllimport) funcA(int a, int b);
int __declspec(dllimport) funcB(int a, int b);

int main(int argc, char *argv[])
{
	printf("funcA(2, 3) = %d\n", funcA(2, 3));
	printf("funcB(2, 3) = %d\n", funcB(2, 3));
	return 0;
}
