#include <windows.h>

int __declspec(dllexport) funcA(int a, int b)
{
	MessageBox(GetDesktopWindow(), "funcA", "captionA", MB_OK);
	a = funcC(b);
	return a + b + 1;
}
int __declspec(dllexport) funcB(int a, int b)
{
	MessageBox(GetDesktopWindow(), "funcB", "captionB", MB_OK);
	b = funcC(a);
	return a * b + 1;
}

int funcC(int c)
{
	return c * 2;
}
