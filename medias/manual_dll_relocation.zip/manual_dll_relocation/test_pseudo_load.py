import sys, logging, struct, ctypes

# {{{ data structure definitions

BYTE = ctypes.c_ubyte
WORD = ctypes.c_ushort
LONG = ctypes.c_long
DWORD = ctypes.c_ulong
RVA = ctypes.c_ulong

class IMAGE_DOS_HEADER(ctypes.Structure):
  _fields_ = [
      ('e_magic', WORD), # Magic number
      ('e_cblp', WORD), # Bytes on last page of file
      ('e_cp', WORD), # Pages in file
      ('e_crlc', WORD), # Relocations
      ('e_cparhdr', WORD), # Size of header in paragraphs
      ('e_minalloc', WORD), # Minimum extra paragraphs needed
      ('e_maxalloc', WORD), # Maximum extra paragraphs needed
      ('e_ss', WORD), # Initial (relative) SS value
      ('e_sp', WORD), # Initial SP value
      ('e_csum', WORD), # Checksum
      ('e_ip', WORD), # Initial IP value
      ('e_cs', WORD), # Initial (relative) CS value
      ('e_lfarlc', WORD), # File address of relocation table
      ('e_ovno', WORD), # Overlay number
      ('e_res', WORD * 4), # Reserved words
      ('e_oemid', WORD), # OEM identifier (for e_oeminfo)
      ('e_oeminfo', WORD), # OEM information; e_oemid specific
      ('e_res2', WORD * 10), # Reserved words
      ('e_lfanew', LONG), # File address of new exe header
      ]

class IMAGE_FILE_HEADER(ctypes.Structure):
  _fields_ = [
      ('Machine', WORD),
      ('NumberOfSections', WORD),
      ('TimeDateStamp', DWORD),
      ('PointerToSymbolTable', DWORD),
      ('NumberOfSymbols', DWORD),
      ('SizeOfOptionalHeader', WORD),
      ('Characteristics', WORD),
      ]

class IMAGE_DATA_DIRECTORY(ctypes.Structure):
  _fields_ = [
      ('VirtualAddress', DWORD),
      ('Size', DWORD),
      ]

IMAGE_NUMBEROF_DIRECTORY_ENTRIES = 16

IMAGE_DIRECTORY_ENTRY_EXPORT         =  0 #  Export Directory
IMAGE_DIRECTORY_ENTRY_IMPORT         =  1 #  Import Directory
IMAGE_DIRECTORY_ENTRY_RESOURCE       =  2 #  Resource Directory
IMAGE_DIRECTORY_ENTRY_EXCEPTION      =  3 #  Exception Directory
IMAGE_DIRECTORY_ENTRY_SECURITY       =  4 #  Security Directory
IMAGE_DIRECTORY_ENTRY_BASERELOC      =  5 #  Base Relocation Table
IMAGE_DIRECTORY_ENTRY_DEBUG          =  6 #  Debug Directory
IMAGE_DIRECTORY_ENTRY_ARCHITECTURE   =  7 #  Architecture Specific Data
IMAGE_DIRECTORY_ENTRY_GLOBALPTR      =  8 #  RVA of GP
IMAGE_DIRECTORY_ENTRY_TLS            =  9 #  TLS Directory
IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG    = 10 #  Load Configuration Directory
IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT   = 11 #  Bound Import Directory in headers
IMAGE_DIRECTORY_ENTRY_IAT            = 12 #  Import Address Table
IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT   = 13 #  Delay Load Import Descriptors
IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR = 14 #  COM Runtime descriptor


class IMAGE_OPTIONAL_HEADER(ctypes.Structure):
  _fields_ = [
      ('Magic', WORD),
      ('MajorLinkerVersion', BYTE),
      ('MinorLinkerVersion', BYTE),
      ('SizeOfCode', DWORD),
      ('SizeOfInitializedData', DWORD),
      ('SizeOfUninitializedData', DWORD),
      ('AddressOfEntryPoint', DWORD),
      ('BaseOfCode', DWORD),
      ('BaseOfData', DWORD),
      ('ImageBase', DWORD),
      ('SectionAlignment', DWORD),
      ('FileAlignment', DWORD),
      ('MajorOperatingSystemVersion', WORD),
      ('MinorOperatingSystemVersion', WORD),
      ('MajorImageVersion', WORD),
      ('MinorImageVersion', WORD),
      ('MajorSubsystemVersion', WORD),
      ('MinorSubsystemVersion', WORD),
      ('Win32VersionValue', DWORD),
      ('SizeOfImage', DWORD),
      ('SizeOfHeaders', DWORD),
      ('CheckSum', DWORD),
      ('Subsystem', WORD),
      ('DllCharacteristics', WORD),
      ('SizeOfStackReserve', DWORD),
      ('SizeOfStackCommit', DWORD),
      ('SizeOfHeapReserve', DWORD),
      ('SizeOfHeapCommit', DWORD),
      ('LoaderFlags', DWORD),
      ('NumberOfRvaAndSizes', DWORD),
      ('DataDirectory', IMAGE_DATA_DIRECTORY * IMAGE_NUMBEROF_DIRECTORY_ENTRIES ),
      ]

class IMAGE_NT_HEADERS(ctypes.Structure):
  _fields_ = [
      ('Signature', DWORD),
      ('FileHeader', IMAGE_FILE_HEADER),
      ('OptionalHeader', IMAGE_OPTIONAL_HEADER),
      ]

IMAGE_SIZEOF_SHORT_NAME = 8

class IMAGE_SECTION_HEADER_MISC(ctypes.Union):
  _fields_ = [
      ('PhysicalAddress', DWORD),
      ('VirtualSize', DWORD),
      ]

class IMAGE_SECTION_HEADER(ctypes.Structure):
  _fields_ = [
      ('Name', BYTE * IMAGE_SIZEOF_SHORT_NAME),
      ('Misc', IMAGE_SECTION_HEADER_MISC),
      ('VirtualAddress', DWORD),
      ('SizeOfRawData', DWORD),
      ('PointerToRawData', DWORD),
      ('PointerToRelocations', DWORD),
      ('PointerToLinenumbers', DWORD),
      ('NumberOfRelocations', WORD),
      ('NumberOfLinenumbers', WORD),
      ('Characteristics', DWORD),
      ]

class IMAGE_IMPORT_DESCRIPTOR_MISC(ctypes.Union):
  _fields_ = [
      # 0 for terminating null import descriptor
      ('Characteristics', DWORD), 
      #  RVA to original unbound IAT (PIMAGE_THUNK_DATA)
      ('OriginalFirstThunk', DWORD), 
      ]

class IMAGE_IMPORT_DESCRIPTOR(ctypes.Structure):
  _fields_ = [
      ('Misc', IMAGE_IMPORT_DESCRIPTOR_MISC),
      # 0 if not bound,
      # -1 if bound, and real date/time stamp
      #     in IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT (new BIND)
      # O.W. date/time stamp of DLL bound to (Old BIND)
      ('TimeDateStamp', DWORD),
      ('ForwarderChain', DWORD), # -1 if no forwarders
      ('Name', DWORD), 
      # RVA to IAT (if bound this IAT has actual addresses)
      ('FirstThunk', DWORD), 
      ]


class IMAGE_IMPORT_BY_NAME(ctypes.Structure):
  _fields_ = [
      ('Hint', WORD),
      ('Name', BYTE),
      ]

class IMAGE_THUNK_DATA(ctypes.Union):
  _fields_ = [
      ('ForwarderString', DWORD), # PBYTE
      ('Function', DWORD), # PDWORD
      ('Ordinal', DWORD), 
      ('AddressOfData', DWORD), # PIMAGE_IMPORT_BY_NAME
      ]

IMAGE_ORDINAL_FLAG64 = 0x8000000000000000
IMAGE_ORDINAL_FLAG32 = 0x80000000

def IMAGE_ORDINAL64(Ordinal):
  return (Ordinal & 0xffff)

def IMAGE_ORDINAL32(Ordinal):
  return (Ordinal & 0xffff)

def IMAGE_SNAP_BY_ORDINAL64(Ordinal):
  return ((Ordinal & IMAGE_ORDINAL_FLAG64) != 0)

def IMAGE_SNAP_BY_ORDINAL32(Ordinal):
  return ((Ordinal & IMAGE_ORDINAL_FLAG32) != 0)

class IMAGE_EXPORT_DIRECTORY(ctypes.Structure):
  _fields_ = [
      ('Characteristics', DWORD),
      ('TimeDateStamp', DWORD),
      ('MajorVersion', WORD),
      ('MinorVersion', WORD),
      ('Name', DWORD),
      ('Base', DWORD),
      ('NumberOfFunctions', DWORD),
      ('NumberOfNames', DWORD),
      ('AddressOfFunctions', DWORD),
      ('AddressOfNames', DWORD),
      ('AddressOfNameOrdinals', DWORD),
      ]

class IMAGE_BOUND_IMPORT_DESCRIPTOR(ctypes.Structure):
  _fields_ = [
      ('TimeDateStamp', DWORD),
      ('OffsetModuleName', WORD),
      ('NumberOfModuleForwarderRefs', WORD),
      # Array of zero or more IMAGE_BOUND_FORWARDER_REF follows
      ]

class IMAGE_BOUND_FORWARDER_REF(ctypes.Structure):
  _fields_ = [
      ('TimeDateStamp', DWORD),
      ('OffsetModuleName', WORD),
      ('Reserved', WORD),
      ]

class ImgDelayDescr(ctypes.Structure):
  _fields_ = [
      ('grAttrs', DWORD),
      ('rvaDLLName', RVA),
      ('rvaHmod', RVA),
      ('rvaIAT', RVA),
      ('rvaINT', RVA),
      ('rvaBoundIAT', RVA),
      ('rvaUnloadIAT', RVA),
      ('dwTimeStamp', DWORD),
      ]

class IMAGE_BASE_RELOCATION(ctypes.Structure):
  _fields_ = [
      ('VirtualAddress', DWORD),
      ('SizeOfBlock', DWORD),
      # ('TypeOffset', WORD * ?),
      ]

IMAGE_REL_BASED_ABSOLUTE       = 0
IMAGE_REL_BASED_HIGH           = 1
IMAGE_REL_BASED_LOW            = 2
IMAGE_REL_BASED_HIGHLOW        = 3
IMAGE_REL_BASED_HIGHADJ        = 4
IMAGE_REL_BASED_MIPS_JMPADDR   = 5
IMAGE_REL_BASED_MIPS_JMPADDR16 = 9
IMAGE_REL_BASED_IA64_IMM64     = 9
IMAGE_REL_BASED_DIR64          = 10

IMAGE_REL_BAESD_TYPES = [
    'ABSOLUTE',       # 0
    'HIGH',           # 1
    'LOW',            # 2
    'HIGHLOW',        # 3
    'HIGHADJ',        # 4
    'MIPS_JMPADDR',   # 5
    'UNKNOWN',        # 6
    'UNKNOWN',        # 7
    'UNKNOWN',        # 8
    'MIPS_JMPADDR16 or IA64_IMM64', # 9
    'DIR64',          # 10
    ]

# }}}
# {{{ def dump_base_relocations()

def dump_base_relocations(base_relocations, image_base_addr):
  for br in base_relocations:
    print "-----------------"
    print "VirtualAddress = 0x%08X" % br.VirtualAddress
    print "SizeOfBlock = 0x%08X" % br.SizeOfBlock
    print "\t[TYPE],\t[OFFSET],\t[FILE VALUE]"
    for br_type in br.types:
      rel_base_type = (0xF000 & br_type.value) >> 12
      rel_base_offset = 0xFFF & br_type.value
      file_value = DWORD()
      ctypes.memmove(
          ctypes.addressof(file_value),
          image_base_addr + br.VirtualAddress + rel_base_offset,
          ctypes.sizeof(DWORD))
      print "\t%s,\t%X h,\t%X" % (
          IMAGE_REL_BAESD_TYPES[rel_base_type], 
          rel_base_offset,
          file_value.value
          )

# }}}
# {{{ def relocate_base_relocations()

def relocate_base_relocations(base_relocations, image_base_addr, diff):
  for br in base_relocations:
    dword_sz = ctypes.sizeof(DWORD)
    for br_type in br.types:
      rel_base_type = (0xF000 & br_type.value) >> 12
      rel_base_offset = 0xFFF & br_type.value
      if IMAGE_REL_BASED_HIGHLOW != rel_base_type:
        continue
      file_value = DWORD()
      target_addr = image_base_addr + br.VirtualAddress + rel_base_offset
      ctypes.memmove(ctypes.addressof(file_value), target_addr, dword_sz)
      original_value = file_value.value
      relocate_value = DWORD(original_value + diff)
      buf_addr = ctypes.addressof(relocate_value)
      ctypes.memmove(target_addr, buf_addr, dword_sz)

# }}}
# {{{ def build_base_relocations()

def build_base_relocations(image_opt_header, image_base_addr):
  brs = []

  br_entry = image_opt_header.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC]
  br_rva = br_entry.VirtualAddress
  br_head = image_base_addr + br_rva
  br_tail = br_head + br_entry.Size

  if 0 == br_rva:
    return brs

  br_sz = ctypes.sizeof(IMAGE_BASE_RELOCATION)
  br_type_sz = ctypes.sizeof(WORD)
  offset = br_head
  while 1:
    br = IMAGE_BASE_RELOCATION()
    ctypes.memmove(
        ctypes.addressof(br),
        offset,
        br_sz)
    br.types = []
    offset = offset + br_sz
    br_types_num = (br.SizeOfBlock - br_sz) / br_type_sz
    for i in xrange(br_types_num):
      br_type = WORD()
      ctypes.memmove(
          ctypes.addressof(br_type),
          offset,
          br_type_sz)
      offset = offset + br_type_sz
      br.types.append(br_type)
    brs.append(br)
    if offset + 1 > br_tail:
      break
  return brs

# }}}
# {{{ def build_first_thunks()

def build_first_thunks(import_descriptor, image_base_addr):

  # enumerate FirstThunk records
  ft_thunk_head = image_base_addr + import_descriptor.FirstThunk
  ft_thunk_sz = ctypes.sizeof(IMAGE_THUNK_DATA)
  ft_thunks = []
  ft_thunk_offset = 0
  while 1:
    ft_thunk = IMAGE_THUNK_DATA()
    ctypes.memmove(
        ctypes.addressof(ft_thunk),
        ft_thunk_head + ft_thunk_offset,
        ft_thunk_sz)
    ft_thunk._VirtualAddress_ = ft_thunk_head + ft_thunk_offset
    ft_thunk_offset = ft_thunk_offset + ft_thunk_sz
    if 0 == ft_thunk.Ordinal :
      break
    ft_thunks.append(ft_thunk)

  return ft_thunks

# }}}
# {{{ def build_original_first_thunks()

def build_original_first_thunks(import_descriptor, image_base_addr):

  oft_thunk_head = image_base_addr + import_descriptor.Misc.OriginalFirstThunk
  oft_thunks = []
  oft_thunk_sz = ctypes.sizeof(IMAGE_THUNK_DATA)
  oft_thunk_offset = 0
  if 0 == oft_thunk_head:
    return oft_thunks

  while 1:
    oft_thunk = IMAGE_THUNK_DATA()
    ctypes.memmove(
        ctypes.addressof(oft_thunk),
        oft_thunk_head + oft_thunk_offset,
        oft_thunk_sz)
    oft_thunk._VirtualAddress_ = oft_thunk_head + oft_thunk_offset
    oft_thunk_offset = oft_thunk_offset + oft_thunk_sz
    if 0 == oft_thunk.Ordinal :
      break
    oft_thunk._Ordinal_ = 0
    oft_thunk._Hint_ = 0
    oft_thunk._Name_ = ""
    oft_thunks.append(oft_thunk)

  for oft_thunk in oft_thunks:
    if IMAGE_SNAP_BY_ORDINAL32(oft_thunk.Ordinal):
      # Ordinal
      oft_thunk._Ordinal_ = IMAGE_ORDINAL32(oft_thunk.Ordinal)
    else:
      # Hint
      hint_data = IMAGE_IMPORT_BY_NAME()
      hint_data_sz = ctypes.sizeof(IMAGE_IMPORT_BY_NAME)
      ctypes.memmove(
          ctypes.addressof(hint_data),
          image_buf_ptr + oft_thunk.AddressOfData,
          hint_data_sz)
      oft_thunk._Hint_ = hint_data.Hint
      # Name
      hint_data_name_ptr = image_buf_ptr + \
          oft_thunk.AddressOfData + \
          ctypes.sizeof(WORD)
      hint_data_name = ctypes.c_char_p(hint_data_name_ptr)
      oft_thunk._Name_ = hint_data_name.value

  return oft_thunks

# }}}
# {{{ def build_import_descriptors()

def build_import_descriptors(image_opt_header, image_base_addr):

  entry = image_opt_header.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT]
  rva = entry.VirtualAddress
  head = image_base_addr + rva

  # build IMAGE_IMPORT_DESCRIPTOR array
  records = []
  record_sz = ctypes.sizeof(IMAGE_IMPORT_DESCRIPTOR)
  offset = head
  while 1:
    record = IMAGE_IMPORT_DESCRIPTOR()
    ctypes.memmove(
        ctypes.addressof(record), 
        offset,
        record_sz)
    offset = offset + record_sz
    if 0 == record.FirstThunk:
      break

    record._FirstThunks_ = build_first_thunks(record, image_base_addr)
    record._OriginalFirstThunks_ = build_original_first_thunks(record, image_base_addr)
    records.append(record)

  return records

# }}}
# {{{ def dump_import_descriptors()

def dump_import_descriptors(import_descriptors, image_base_addr):
  for d in import_descriptors:
    module_name = ctypes.c_char_p(image_base_addr + d.Name)
    print "[%s]" % module_name.value
    for ft_thunk in d._FirstThunks_:
      print "FirstThunk: %08X" % ft_thunk.Ordinal
      print "\t(Original VirtualAddress = %08X)" % ft_thunk._VirtualAddress_
    for oft_thunk in d._OriginalFirstThunks_:
      print "OriginalFirstThunk: %08X" % oft_thunk.Ordinal
      print "\t(Original VirtualAddress = %08X)" % oft_thunk._VirtualAddress_
      if 0 == oft_thunk._Ordinal_:
        print "\tHint: %04X" % oft_thunk._Hint_
        print "\tName: %s" % oft_thunk._Name_
      else:
        print "\tOrdinal: %d" % oft_thunk._Ordinal_

# }}}
# {{{ def import_dlls()

def import_dlls(import_descriptors, image_base_addr):
  for d in import_descriptors:
    # retrieve module name
    module_name = ctypes.c_char_p(image_base_addr + d.Name)
    # call LoadLibraryA()
    hModule = ctypes.windll.kernel32.LoadLibraryA(module_name.value)

    index = 0
    for oft_thunk in d._OriginalFirstThunks_:
      # retrieve function name
      func_name = ""
      if 0 == oft_thunk._Ordinal_:
        func_name = oft_thunk._Name_
      else:
        # not supported for ordinal import
        index = index + 1
        continue
      # call GetProcAddress()
      func_addr = ctypes.windll.kernel32.GetProcAddress(hModule, func_name)
      # overwrite to IAT
      dword_func_addr = DWORD(func_addr)
      ft_thunk = d._FirstThunks_[index]
      ctypes.memmove(
        ft_thunk._VirtualAddress_,
        ctypes.addressof(dword_func_addr),
        ctypes.sizeof(DWORD))
      index = index + 1

# }}}
# {{{ def build_export_directory()

def build_export_directory(image_opt_header, section_headers, image_base_addr):

  entry = opt_header.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT]
  rva = entry.VirtualAddress
  head = image_buf_ptr + rva

  record = IMAGE_EXPORT_DIRECTORY()
  ctypes.memmove(
      ctypes.addressof(record), 
      head,
      ctypes.sizeof(IMAGE_EXPORT_DIRECTORY))

  name = ctypes.c_char_p(image_base_addr + record.Name)
  record._Name_ = name.value

  # Exported Function Addresses
  record._Functions_ = []
  function_rva_sz = ctypes.sizeof(DWORD)
  offset = image_base_addr + record.AddressOfFunctions
  for i in xrange(record.NumberOfFunctions):
    function_rva = DWORD()
    ctypes.memmove(
        ctypes.addressof(function_rva), 
        offset, 
        function_rva_sz)
    offset = offset + function_rva_sz
    # ignore dll forwarding
    record._Functions_.append(function_rva.value)

  # Exported Names
  record._Names_ = []
  name_rva_sz = ctypes.sizeof(DWORD)
  offset = image_base_addr + record.AddressOfNames
  for i in xrange(record.NumberOfNames):
    name_rva = DWORD()
    ctypes.memmove(
        ctypes.addressof(name_rva), 
        offset, 
        name_rva_sz)
    offset = offset + name_rva_sz
    name = ctypes.c_char_p(image_base_addr + name_rva.value)
    record._Names_.append(name.value)

  # Exported Ordinals
  record._Ordinals_ = []
  ordinal_sz = ctypes.sizeof(WORD)
  offset = image_base_addr + record.AddressOfNameOrdinals
  for i in xrange(record.NumberOfNames):
    ordinal = WORD()
    ctypes.memmove(
        ctypes.addressof(ordinal), 
        offset, 
        ordinal_sz)
    offset = offset + ordinal_sz
    record._Ordinals_.append(ordinal.value)

  return record

# }}}
# {{{ def dump_export_directory()

def dump_export_directory(d):
  print ">>> IMAGE_EXPORT_DIRECTORY <<<"
  print "Characteristics = %04X" % d.Characteristics
  print "TimeDateStamp = %04X" % d.TimeDateStamp
  print "MajorVersion = %02X" % d.MajorVersion
  print "MinorVersion = %02X" % d.MinorVersion
  print "Name = %s [RVA=%04X]" % (d._Name_, export_directory.Name)
  print "Base = %04X" % d.Base
  print "NumberOfFunctions = %04X" % d.NumberOfFunctions
  print "NumberOfNames = %04X" % d.NumberOfNames
  print "AddressOfFunctions RVA = %04X" % d.AddressOfFunctions
  print "AddressOfNames RVA = %04X" % d.AddressOfNames
  print "AddressOfNameOrdinals RVA = %04X" % d.AddressOfNameOrdinals

  i = 0
  print "-----------------"
  print "Functions:"
  for v in d._Functions_:
    print "\tFunction[%d] RVA = %08X" % (i, v)
    i = i + 1

  i = 0
  print "-----------------"
  print "Names:"
  for v in d._Names_:
    print "\tName[%d] = %s" % (i, v)
    i = i + 1

  i = 0
  print "-----------------"
  print "Ordinals:"
  for v in d._Ordinals_:
    print "\tOrdinal[%d] = %d" % (i, v)
    i = i + 1

# }}}
# {{{ def get_export_address()

def get_export_address(d, name):

  i = 0
  found = False
  for v in d._Names_:
    if v == name:
      found = True
      break
    i = i + 1

  if not found:
    return 0

  o = d._Ordinals_[i]

  return d._Functions_[o]

# }}}

if 2 != len(sys.argv):
  print 'usage: python %s filename' % sys.argv[0]
  quit()

file_name = sys.argv[1]

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s %(name)s %(levelname)s %(message)s',
    )
log = logging.getLogger('main')

try:
  f = open(file_name, 'rb')
except IOError, e:
  log.error("open(%s) faileed." % file_name)
  log.error(e)
  raise e

# {{{ read IMAGE_DOS_HEADER

f.seek(0, 0)
sz = ctypes.sizeof(IMAGE_DOS_HEADER)
data = f.read(sz)
dos_header = IMAGE_DOS_HEADER()
fit = min(len(data), sz)
ctypes.memmove(ctypes.addressof(dos_header), data, fit)

# }}}
# {{{ read IMAGE_NT_HEADERS

f.seek(dos_header.e_lfanew, 0)
sz = ctypes.sizeof(IMAGE_NT_HEADERS)
data = f.read(sz)
pe_header = IMAGE_NT_HEADERS()
fit = min(len(data), sz)
ctypes.memmove(ctypes.addressof(pe_header), data, fit)

file_header = pe_header.FileHeader
opt_header = pe_header.OptionalHeader

# }}}
# {{{ enumerate IMAGE_SECTION_HEADER array
section_headers = []
section_header_sz = ctypes.sizeof(IMAGE_SECTION_HEADER)
for i in range(file_header.NumberOfSections):
  data = f.read(section_header_sz)
  section_header = IMAGE_SECTION_HEADER()
  fit = min(len(data), sz)
  ctypes.memmove(ctypes.addressof(section_header), data, fit)
  section_headers.append(section_header)

# }}}
# {{{ load to memory
f.seek(0, 0)
file_bytes = f.read() # read all file contents
MEM_COMMIT = 0x1000
PAGE_EXECUTE_READWRITE = 0x40

image_buf_ptr = ctypes.windll.kernel32.VirtualAlloc(
    None,
    opt_header.SizeOfImage,
    MEM_COMMIT,
    PAGE_EXECUTE_READWRITE
    )

# copy headers
ctypes.memmove(
    image_buf_ptr, 
    file_bytes,
    opt_header.SizeOfHeaders
    )

# copy section datas
for h in section_headers:
  section_virtual_addr = h.VirtualAddress
  pointer_to_rawdata = h.PointerToRawData
  size_of_rawdata = h.SizeOfRawData
  if pointer_to_rawdata :
    ctypes.memmove(
        image_buf_ptr + section_virtual_addr,
        file_bytes[pointer_to_rawdata:pointer_to_rawdata + size_of_rawdata],
        size_of_rawdata)

# }}}

base_relocations = build_base_relocations(opt_header, image_buf_ptr)

if 0 == len(base_relocations):
  print "NO BASE RELOCATIONS"
  quit()

print "-------[ RELOCATION INFO : BEFORE RELOCATION ]-------"
dump_base_relocations(base_relocations, image_buf_ptr)
print "-----------------------------------------------------"
print

print "File ImageBase = 0x%08X" % opt_header.ImageBase
print "Real ImageBase = 0x%08X" % image_buf_ptr
diff = image_buf_ptr - opt_header.ImageBase
print "Differencial = 0x%08X" % diff
print

relocate_base_relocations(base_relocations, image_buf_ptr, diff)
raw_input('Pausing ... Hit Return for Continue :')

print "-------[ RELOCATION INFO : AFTER RELOCATION ]-------"
dump_base_relocations(base_relocations, image_buf_ptr)
print "----------------------------------------------------"
print

ids1 = build_import_descriptors(opt_header, image_buf_ptr)
print "-------[ IMPORT INFO : BEFORE IMPORTING ]-------"
dump_import_descriptors(ids1, image_buf_ptr)
print "------------------------------------------------"
print

import_dlls(ids1, image_buf_ptr)
raw_input('Pausing ... Hit Return for Continue :')

ids2 = build_import_descriptors(opt_header, image_buf_ptr)
print "-------[ IMPORT INFO : AFTER IMPORTING ]-------"
dump_import_descriptors(ids2, image_buf_ptr)
print "-----------------------------------------------"
print

export_directory = build_export_directory(
    opt_header, section_headers, image_buf_ptr)

print "-------[ EXPORT INFO ]-------"
dump_export_directory(export_directory)
print "-----------------------------"
print


raw_input('O.K, Here we go ... Hit Return for Continue :')

addr_funcA = image_buf_ptr + get_export_address(export_directory, 'funcA')
print "funcA = %08X" % addr_funcA
addr_funcB = image_buf_ptr + get_export_address(export_directory, 'funcB')
print "funcB = %08X" % addr_funcB

prototypes = {
    'funcA' : ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.c_int),
    'funcB' : ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.c_int),
    }

funcA = prototypes['funcA'](addr_funcA)
funcB = prototypes['funcB'](addr_funcB)

print "funcA(2, 3) = %d" % funcA(2, 3)
print "funcB(2, 3) = %d" % funcB(2, 3)
