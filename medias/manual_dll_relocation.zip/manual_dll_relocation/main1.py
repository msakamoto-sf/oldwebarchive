import ctypes

dlltest = ctypes.cdll.dlltest
print "funcA(2, 3) = %d" % dlltest.funcA(2, 3)
print "funcB(2, 3) = %d" % dlltest.funcB(2, 3)
