import ctypes

hModule = ctypes.windll.kernel32.LoadLibraryA('dlltest.dll')
print "hModule = 0x%08X" % hModule
addr_funcA = ctypes.windll.kernel32.GetProcAddress(hModule, 'funcA')
print "Address of 'funcA' = 0x%08X" % addr_funcA
addr_funcB = ctypes.windll.kernel32.GetProcAddress(hModule, 'funcB')
print "Address of 'funcB' = 0x%08X" % addr_funcB

prototypes = {
    'funcA' : ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.c_int),
    'funcB' : ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.c_int),
    }

funcA = prototypes['funcA'](addr_funcA)
funcB = prototypes['funcB'](addr_funcB)
print "funcA(2, 3) = %d" % funcA(2, 3)
print "funcB(2, 3) = %d" % funcB(2, 3)
