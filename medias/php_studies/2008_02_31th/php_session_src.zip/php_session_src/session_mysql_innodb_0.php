<?php
define('SESSION_DB_HOST', 'localhost');
define('SESSION_DB_USER', 'root');
define('SESSION_DB_PASS', '');
define('SESSION_DB_DATABASE', 'php_sess_acid');
define('SESSION_DB_TABLE', 'sess_innodb');

$sess_db = null;

// http://jp.php.net/manual/ja/function.session-set-save-handler.php

function dlog($msg)
{
    $msg = sprintf("[%s] %s", @$_GET['sleep'], $msg);
    trigger_error($msg, E_USER_NOTICE);
}

function sess_query($query)
{
    global $sess_db;
    $ret = mysql_query($query, $sess_db);
    if (!$ret) {
        die(mysql_error());
    }
}

function sess_open()
{
    global $sess_db;
    if ($sess_db = mysql_connect(
        SESSION_DB_HOST, 
        SESSION_DB_USER, 
        SESSION_DB_PASS)
    ) {
        if (!mysql_select_db(SESSION_DB_DATABASE, $sess_db)) {
            die(mysql_error());
        }
        sess_query('SET AUTOCOMMIT=0');
        sess_query('START TRANSACTION');
        sess_query('BEGIN');
        dlog("transaction start");
        return true;
    }
    return false;
}

function sess_close()
{
    global $sess_db;
    sess_query('COMMIT');
    $ret = mysql_close($sess_db);
    dlog("transaction end");
    return $ret;
}

function sess_read($id)
{
    global $sess_db;
    $id = mysql_real_escape_string($id);
    $sql = sprintf("SELECT `data` FROM `" . SESSION_DB_TABLE . "` " .
        "WHERE id = '%s'", $id);
    $ret = '';
    dlog("select start");
    if ($result = mysql_query($sql, $sess_db)) {
        if (mysql_num_rows($result)) {
            $record = mysql_fetch_assoc($result);
            $ret = $record['data'];
        }
    }
    dlog("select end");
    return $ret;
}

function sess_write($id, $data)
{
    global $sess_db;
    $sql = sprintf("REPLACE INTO `" . SESSION_DB_TABLE 
        . "` VALUES('%s', '%s', '%s')",
        mysql_real_escape_string($id),
        mysql_real_escape_string($data),
        mysql_real_escape_string(time()));
    dlog("replace start");
    $ret = mysql_query($sql, $sess_db);
    dlog("replace end");
    return $ret;
}

function sess_destroy($id)
{
    global $sess_db;
    $sql = sprintf("DELETE FROM `" . SESSION_DB_TABLE 
        . "` WHERE `id` = '%s'", $id);
    return mysql_query($sql, $sess_db);
}

function sess_gc($max)
{
    global $sess_db;
    $sql = sprintf("DELETE FROM `" . SESSION_DB_TABLE 
        . "` WHERE `timestamp` < '%s'",
        mysql_real_escape_string(time() - $max));
    return mysql_query($sql, $sess_db);
}

ini_set('session.save_handler', 'user');
session_set_save_handler(
    'sess_open',
    'sess_close',
    'sess_read',
    'sess_write',
    'sess_destroy',
    'sess_gc'
);

// below sample main

session_start();

$sleep = isset($_GET['sleep']) ? $_GET['sleep'] : 0;

$_SESSION['c'] = isset($_SESSION['c']) ? $_SESSION['c'] + 1 : 1;

if ($sleep) { sleep($sleep); }

echo $_SESSION['c'];
