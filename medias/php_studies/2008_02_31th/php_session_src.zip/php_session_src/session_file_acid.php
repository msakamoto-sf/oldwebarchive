<?php
session_start();

$sleep = isset($_GET['sleep']) ? $_GET['sleep'] : 0;

$_SESSION['c'] = isset($_SESSION['c']) ? $_SESSION['c'] + 1 : 1;

if ($sleep) { sleep($sleep); }

echo $_SESSION['c'];

