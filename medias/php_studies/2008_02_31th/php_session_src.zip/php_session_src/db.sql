CREATE TABLE `sess_innodb` (
  `id` varchar(128) collate utf8_bin NOT NULL,
  `data` text collate utf8_bin NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `sess_myisam` (
  `id` varchar(128) collate utf8_bin NOT NULL,
  `data` text collate utf8_bin NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
