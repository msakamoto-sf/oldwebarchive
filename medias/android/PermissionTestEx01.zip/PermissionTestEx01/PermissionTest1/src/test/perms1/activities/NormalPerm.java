package test.perms1.activities;

import test.perms1.R;
import android.app.Activity;
import android.os.Bundle;

public class NormalPerm extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.normal_perm_public);
    }
}