package test.perms1.services;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

public class NormalPerm extends IntentService {
    public NormalPerm() {
        super("NormalPerm");
    }
    @Override
    protected void onHandleIntent(Intent intent) {
        String srcuri = intent.getData().toString();
        String t = this.getClass().getName() + ":" + srcuri;
        Log.i("test.perms1", t);
    }
}
