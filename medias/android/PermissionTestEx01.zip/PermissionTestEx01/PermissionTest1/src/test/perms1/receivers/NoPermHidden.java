package test.perms1.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class NoPermHidden extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent i) {
        String srcpkg = ctx.getPackageName();
        String srcuri = i.getData().toString();
        String t = this.getClass().getName() + ":From[" + srcpkg + "]:" + srcuri;
        Log.i("test.perms1", t);
        Toast.makeText(ctx, t, Toast.LENGTH_LONG).show();
    }
}
