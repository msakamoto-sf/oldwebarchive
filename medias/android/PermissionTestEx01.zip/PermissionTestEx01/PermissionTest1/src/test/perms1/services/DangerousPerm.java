package test.perms1.services;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

public class DangerousPerm extends IntentService {
    public DangerousPerm() {
        super("DangerousPerm");
    }
    @Override
    protected void onHandleIntent(Intent intent) {
        String srcuri = intent.getData().toString();
        String t = this.getClass().getName() + ":" + srcuri;
        Log.i("test.perms1", t);
    }
}
