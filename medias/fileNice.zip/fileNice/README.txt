fileNice 1.0


What is it?
fileNice is a free php file browser, particularly useful if
you have a 'dump' folder on your server where you regularly 
upload files and you want to be able to see what's there.


Features:
Folder specific slideshows of images (without page reloads).
File details
Send to Flickr
Folder comments
Search
Prefs based sorting


Installation:
Download the fileNice.zip, unpack and upload the folder 
contents into the directory on your server that you want to 
be able to browse.


Skinning:
Not documented yet but it's pretty easy. There's one css file 
and one php css file which generates the icon list (if you 
want custom icons for certain filetypes).


Please send bugs and suggestions to stuff[a]filenice.com

Thanks for your interest.